﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ConditionController : Controller
    {
        private readonly PharmacyContext _context;

        public ConditionController(PharmacyContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var conditions = _context.Conditions
                .Include(c => c.Medicines)
                .ToList();

            return View(conditions);
        }
    }

}
