﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("Medicine")]
    public class MedicineController : Controller
    {
        private readonly PharmacyContext _context;

        public MedicineController(PharmacyContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index(MedicineFilterViewModel filterModel)
        {
            var medicines = _context.Medicines
                .Include(m => m.Category)
                .Include(m => m.Condition)
                .Include(m => m.Supplier)
                .AsQueryable();

            if (filterModel.SelectedCountries.Any())
            {
                medicines = medicines.Where(m => filterModel.SelectedCountries.Contains(m.CountryOfOrigin));
            }

            if (filterModel.SelectedCategories.Any())
            {
                medicines = medicines.Where(m => filterModel.SelectedCategories.Contains(m.Category.CategoryName));
            }

            if (filterModel.SelectedForms.Any())
            {
                medicines = medicines.Where(m => filterModel.SelectedForms.Contains(m.Form));
            }

            if (filterModel.PriceFrom.HasValue)
            {
                medicines = medicines.Where(m => m.Price >= filterModel.PriceFrom.Value);
            }

            if (filterModel.PriceTo.HasValue)
            {
                medicines = medicines.Where(m => m.Price <= filterModel.PriceTo.Value);
            }

            if (!string.IsNullOrWhiteSpace(filterModel.SearchQuery))
            {
                medicines = medicines.Where(m => m.Name.Contains(filterModel.SearchQuery));
            }

            filterModel.Medicines = medicines.ToList();
            return View(filterModel);
        }

        [HttpPost]
        public IActionResult GeneratePdf(int id)
        {
            var medicine = _context.Medicines
                .Include(m => m.Category)
                .Include(m => m.Condition)
                .Include(m => m.Supplier)
                .FirstOrDefault(m => m.MedicineId == id);

            if (medicine == null)
                return NotFound();

            using (MemoryStream stream = new MemoryStream())
            {
                Document doc = new Document(PageSize.A4.Rotate());
                PdfWriter.GetInstance(doc, stream).CloseStream = false;

                BaseFont arial = BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                var fTitle = new iTextSharp.text.Font(arial, 23, iTextSharp.text.Font.BOLD);
                var fText = new iTextSharp.text.Font(arial, 17, iTextSharp.text.Font.NORMAL);

                doc.Open();

                doc.Add(new Paragraph($"Документ - \"Опис препарата\"", fText) { Alignment = Element.ALIGN_RIGHT });
                doc.Add(new Paragraph($"виданий додатком PharmacyGo", fText) { Alignment = Element.ALIGN_RIGHT });
                doc.Add(new Paragraph($"від {DateTime.Now:dd/MM/yyyy}", fText) { Alignment = Element.ALIGN_RIGHT });
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph("Опис препарата - " + medicine.Name, fTitle) { Alignment = Element.ALIGN_CENTER });

                doc.Add(new Paragraph($"Характеристики: форма - {medicine.Form}, виробник - {medicine.Manufacturer}, постачальник - {medicine.Supplier?.SupplierName}", fText));
                doc.Add(new Paragraph($"Країна виробник: {medicine.CountryOfOrigin}", fText));
                doc.Add(new Paragraph($"Рік випуску: {medicine.ReleaseYear}", fText));
                doc.Add(new Paragraph($"Ціна за штуку: {medicine.Price}", fText));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));
                doc.Add(new Paragraph(" "));

                PdfPTable table = new PdfPTable(2);
                table.WidthPercentage = 100;
                table.SetWidths(new float[] { 100f, 100f });

                PdfPCell cellDate = new PdfPCell(new Phrase("Дата: " + DateTime.Now.ToString("dd/MM/yyyy"), fText));
                cellDate.Border = Rectangle.NO_BORDER;
                cellDate.HorizontalAlignment = Element.ALIGN_LEFT;

                PdfPCell cellPharmacy = new PdfPCell(new Phrase("PharmacyGo", fText));
                cellPharmacy.Border = Rectangle.NO_BORDER;
                cellPharmacy.HorizontalAlignment = Element.ALIGN_RIGHT;

                table.AddCell(cellDate);
                table.AddCell(cellPharmacy);
                doc.Add(table);

                doc.Close();

                byte[] pdfBytes = stream.ToArray();
                return File(pdfBytes, "application/pdf", $"Опис_{medicine.Name}.pdf");
            }
        }


    }
}