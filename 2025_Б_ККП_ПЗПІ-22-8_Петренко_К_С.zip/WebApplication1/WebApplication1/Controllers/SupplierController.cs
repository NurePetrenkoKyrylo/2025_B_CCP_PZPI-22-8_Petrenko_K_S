﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class SupplierController : Controller
    {
        private readonly PharmacyContext _context;
        public SupplierController(PharmacyContext context) => _context = context;

        public IActionResult Index() => View(_context.Suppliers.ToList());
    }

}
