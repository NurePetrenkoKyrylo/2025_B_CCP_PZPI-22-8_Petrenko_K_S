﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using System.Net.Mail;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Linq;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace WebApplication1.Controllers
{
    public class AuthController : Controller
    {
        private readonly PharmacyContext _context;
        private readonly ILogger<AuthController> _logger;

        public AuthController(PharmacyContext context, ILogger<AuthController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        public IActionResult Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var exists = _context.Clients.Any(c => c.Email == model.Email);
            if (exists)
            {
                ModelState.AddModelError("Email", "Користувач із таким email вже існує.");
                return View(model);
            }

            var client = new Client
            {
                ClientFirstName = model.FirstName,
                ClientLastName = model.LastName,
                ClientFatherName = model.FatherName,
                Country = model.Country,
                Phone = model.Phone,
                Email = model.Email,
                Address = model.Address
            };

            _context.Clients.Add(client);
            _context.SaveChanges();

            TempData["UserEmail"] = model.Email;
            return RedirectToAction("Login");
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult SendCode(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View("Login", model);

            var user = _context.Clients.FirstOrDefault(c => c.Email == model.Email);
            if (user == null)
            {
                ModelState.AddModelError("Email", "Email не знайдено");
                return View("Login", model);
            }

            var code = new Random().Next(100000, 999999).ToString();
            TempData["AuthCode"] = code;
            TempData["UserId"] = user.ClientId;
            TempData["UserEmail"] = user.Email;

            try
            {
                var smtp = new SmtpClient("smtp.gmail.com")
                {
                    Port = 587,
                    EnableSsl = true,
                    Credentials = new NetworkCredential("pharmacygo504@gmail.com", "jabudgkjmusqamcm")
                };

                smtp.Send("pharmacygo504@gmail.com", user.Email, "Код підтвердження", $"Ваш код: {code}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Помилка при надсиланні листа");
                ModelState.AddModelError("", "Помилка надсилання email");
                return View("Login", model);
            }

            return RedirectToAction("VerifyCode");
        }

        [HttpGet]
        public IActionResult VerifyCode()
        {
            var email = TempData["UserEmail"] as string;
            TempData.Keep("UserEmail");
            TempData.Keep("AuthCode");
            TempData.Keep("UserId");

            var model = new VerifyCodeViewModel
            {
                Email = email
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> VerifyCode(VerifyCodeViewModel model)
        {
            var expectedCode = TempData["AuthCode"] as string;
            var userId = TempData["UserId"] as int?;

            _logger.LogInformation("Received code: '{code}', expected: '{expected}'", model.Code, expectedCode);

            if (model.Code == expectedCode && userId != null)
            {
                HttpContext.Session.SetInt32("user_id", userId.Value);

                var user = _context.Clients.FirstOrDefault(c => c.ClientId == userId.Value);
                if (user == null)
                {
                    ModelState.AddModelError("", "Користувача не знайдено");
                    return View(model);
                }

                HttpContext.Session.SetString("client_email", user.Email);

                var claims = new List<Claim>
        {
            new Claim(ClaimTypes.NameIdentifier, user.ClientId.ToString()),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Name, $"{user.ClientFirstName} {user.ClientLastName}")
        };

                var claimsIdentity = new ClaimsIdentity(
                    claims, CookieAuthenticationDefaults.AuthenticationScheme);

                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTimeOffset.UtcNow.AddDays(7)
                };

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                return RedirectToAction("Index", "Profile");
            }

            TempData.Keep("AuthCode");
            TempData.Keep("UserId");
            ModelState.AddModelError("Code", "Неверный код.");
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Medicine");
        }

    }
}
