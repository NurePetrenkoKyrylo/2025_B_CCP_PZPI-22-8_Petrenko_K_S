﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CartController : Controller
    {
        private readonly PharmacyContext _context;
        private readonly ILogger<CartController> _logger;

        public CartController(PharmacyContext context, ILogger<CartController> logger)
        {
            _context = context;
            _logger = logger;
        }

        private List<CartItemViewModel> GetCart()
        {
            return HttpContext.Session.Get<List<CartItemViewModel>>("Cart") ?? new List<CartItemViewModel>();
        }

        private void SaveCart(List<CartItemViewModel> cart)
        {
            HttpContext.Session.Set("Cart", cart);
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int medicineId, int quantity)
        {
            var medicine = await _context.Medicines.FindAsync(medicineId);
            if (medicine == null)
            {
                return NotFound("Ліки не знайдено");
            }

            if (quantity <= 0)
            {
                return BadRequest("Кількість має бути більшою за нуль");
            }

            if (quantity > medicine.InStock)
            {
                if (medicine.InStock == 0)
                {
                    if (User.Identity.IsAuthenticated)
                    {
                        TempData["ShowNotificationModal"] = true;
                        TempData["MedicineId"] = medicineId;
                        return RedirectToAction("Index", "Medicine");
                    }
                    else
                    {
                        HttpContext.Session.SetInt32("PendingNotificationMedicineId", medicineId);
                        return RedirectToAction("Login", "Auth");
                    }
                }
                return BadRequest($"Недостатньо товару у наявності. Доступно: {medicine.InStock}");
            }


            var cart = GetCart();
            var existingItem = cart.FirstOrDefault(item => item.MedicineId == medicineId);

            if (existingItem != null)
            {
                if (existingItem.Quantity + quantity > medicine.InStock)
                {
                    return BadRequest($"Не можна додати таку кількість. Максимум: {medicine.InStock - existingItem.Quantity}");
                }
                existingItem.Quantity += quantity;
                existingItem.TotalPrice = existingItem.Quantity * existingItem.PricePerUnit;
            }
            else
            {
                cart.Add(new CartItemViewModel
                {
                    CartId = cart.Count > 0 ? cart.Max(c => c.CartId) + 1 : 1,
                    MedicineId = medicineId,
                    MedicineName = medicine.Name,
                    PricePerUnit = medicine.Price ?? 0,
                    Quantity = quantity,
                    TotalPrice = (medicine.Price ?? 0) * quantity,
                    ClientId = HttpContext.Session.GetInt32("user_id") ?? 0
                });
            }

            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public IActionResult Index()
        {
            var cart = GetCart();
            ViewBag.TotalAmount = cart.Sum(item => item.TotalPrice);
            return View(cart);
        }

        [HttpPost]
        public IActionResult RemoveFromCart(int cartId)
        {
            var cart = GetCart();
            var itemToRemove = cart.FirstOrDefault(item => item.CartId == cartId);

            if (itemToRemove != null)
            {
                cart.Remove(itemToRemove);
                SaveCart(cart);
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> UpdateQuantity(int cartId, int quantity)
        {
            if (quantity <= 0)
            {
                return BadRequest("Кількість має бути більшою за нуль");
            }

            var cart = GetCart();
            var item = cart.FirstOrDefault(i => i.CartId == cartId);

            if (item == null)
            {
                return NotFound();
            }

            var medicine = await _context.Medicines.FindAsync(item.MedicineId);
            if (medicine == null)
            {
                return NotFound();
            }

            if (quantity > medicine.InStock)
            {
                return BadRequest($"Недостатньо товару в наявності.: {medicine.InStock}");
            }

            item.Quantity = quantity;
            item.TotalPrice = item.PricePerUnit * quantity;
            SaveCart(cart);

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult CheckAuth()
        {
            return Json(new { isAuthenticated = User.Identity.IsAuthenticated });
        }


        [Authorize(AuthenticationSchemes = CookieAuthenticationDefaults.AuthenticationScheme)]
        [HttpPost]
        public async Task<IActionResult> Checkout(bool savePdf)
        {
            var clientId = HttpContext.Session.GetInt32("user_id");
            if (clientId == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            var cart = GetCart();
            if (!cart.Any())
            {
                return RedirectToAction("Index");
            }

            foreach (var item in cart)
            {
                var medicine = await _context.Medicines.FindAsync(item.MedicineId);
                if (medicine == null || medicine.InStock < item.Quantity)
                {
                    return BadRequest($"Товар {item.MedicineName} недоступний у потрібній кількості");
                }
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var order = new Order
                {
                    ClientId = clientId.Value,
                    CartDate = DateOnly.FromDateTime(DateTime.Now),
                    TotalAmount = (int)cart.Sum(item => item.TotalPrice)
                };

                _context.Orders.Add(order);
                await _context.SaveChangesAsync();

                foreach (var item in cart)
                {
                    var medicine = await _context.Medicines.FindAsync(item.MedicineId);
                    medicine.InStock -= item.Quantity;
                    _context.Medicines.Update(medicine);
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                HttpContext.Session.Remove("Cart");

                if (savePdf)
                {
                    List<OrderItemViewModel> orderItems = cart.Select(item => new OrderItemViewModel
                    {
                        MedicineName = item.MedicineName,
                        Quantity = item.Quantity,
                        PricePerUnit = item.TotalPrice / item.Quantity
                    }).ToList();

                    var pdfService = new PdfService();
                    byte[] pdfBytes = pdfService.GenerateOrderPdf(orderItems, order);
                    return File(pdfBytes, "application/pdf", $"Order_{order.OrderId}.pdf");
                }

                return RedirectToAction("OrderConfirmation", new { orderId = order.OrderId });
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Помилка при оформленні замовлення");
                return StatusCode(500, "Виникла помилка при оформленні замовлення");
            }
        }

        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetLastOrder()
        {
            var clientId = HttpContext.Session.GetInt32("user_id");
            if (clientId == null)
            {
                return Unauthorized();
            }

            var lastOrder = await _context.Orders
                .Where(o => o.ClientId == clientId)
                .OrderByDescending(o => o.OrderId)
                .FirstOrDefaultAsync();

            if (lastOrder == null)
            {
                return NotFound();
            }

            return Json(new { orderId = lastOrder.OrderId });
        }

        public async Task<IActionResult> OrderConfirmation(int orderId)
        {
            var order = await _context.Orders
                .Include(o => o.Client)
                .FirstOrDefaultAsync(o => o.OrderId == orderId);

            if (order == null)
            {
                return NotFound();
            }

            var cartItems = await _context.Carts
                .Where(c => c.ClientId == order.ClientId)
                .Include(c => c.Medicine)
                .ToListAsync();

            ViewBag.CartItems = cartItems;

            return View(order);
        }

        [HttpPost]
        public IActionResult ClearNotificationTempData()
        {
            TempData.Remove("ShowNotificationModal");
            return Ok();
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> RequestNotification(int medicineId)
        {
            _logger.LogInformation($"RequestNotification called for medicineId: {medicineId}");
            try
            {
                var clientId = HttpContext.Session.GetInt32("user_id");
                if (clientId == null || clientId == 0)
                {
                    _logger.LogWarning("Спроба запиту на повідомлення без авторизації");
                    return RedirectToAction("Login", "Auth");
                }

                var medicine = await _context.Medicines.FindAsync(medicineId);
                if (medicine == null)
                {
                    _logger.LogWarning($"Препарата с ID {medicineId} не знайдено");
                    return NotFound();
                }

                var existingRequest = await _context.NotificationRequests
                    .FirstOrDefaultAsync(nr => nr.ClientId == clientId && nr.MedicineId == medicineId && nr.EmailSent == 0);

                if (existingRequest == null)
                {
                    var newRequest = new NotificationRequest
                    {
                        ClientId = clientId.Value,
                        MedicineId = medicineId,
                        RequestDate = DateOnly.FromDateTime(DateTime.Now),
                        EmailSent = 0
                    };

                    _context.NotificationRequests.Add(newRequest);
                    await _context.SaveChangesAsync();

                    _logger.LogInformation($"Створено новий запит на повідомлення: ClientId={clientId}, MedicineId={medicineId}");
                }
                else
                {
                    _logger.LogInformation($"Активний запит на повідомлення вже існує: ClientId={clientId}, MedicineId={medicineId}");
                }

                TempData["ShowNotificationModal"] = true;
                return RedirectToAction("Index", "Medicine");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Помилка під час створення запиту на сповіщення");
                return StatusCode(500, "Виникла помилка при обробці запиту");
            }
        }


        /*    public class CartItemViewModel
            {
                public int CartId { get; set; }
                public int MedicineId { get; set; }
                public string MedicineName { get; set; }
                public decimal PricePerUnit { get; set; }
                public int Quantity { get; set; }
                public decimal TotalPrice { get; set; }
                public int ClientId { get; set; }
            }*/


    }
}