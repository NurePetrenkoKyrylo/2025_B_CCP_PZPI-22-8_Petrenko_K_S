﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;
using System.Linq;
using System;

namespace WebApplication1.Controllers
{
    public class ProfileController : Controller
    {
        private readonly PharmacyContext _context;

        public ProfileController(PharmacyContext context)
        {
            _context = context;
        }

        [Authorize]
        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
                return RedirectToAction("Login", "Auth");

            var user = _context.Clients.FirstOrDefault(c => c.ClientId == userId);
            if (user == null)
                return RedirectToAction("Login", "Auth");

            var orders = _context.Orders
                .Where(o => o.ClientId == userId)
                .OrderByDescending(o => o.CartDate)
                .Take(3)
                .ToList();

            ViewBag.Orders = orders;
            return View(user);
        }

        [Authorize]
        public async Task<IActionResult> Orders()
        {
            var clientId = HttpContext.Session.GetInt32("user_id");
            if (clientId == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            var orders = await _context.Orders
                .Where(o => o.ClientId == clientId)
                .OrderByDescending(o => o.CartDate)
                .ToListAsync();

            return View(orders);
        }


        [Authorize]
        [HttpPost]
        public IActionResult UpdateProfile(Client model)
        {
            if (!ModelState.IsValid)
            {
                return View("Index", model);
            }

            var userId = HttpContext.Session.GetInt32("user_id");
            if (userId == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            var user = _context.Clients.Find(userId);
            if (user == null)
            {
                return RedirectToAction("Login", "Auth");
            }

            // Обновляем только разрешенные поля
            user.ClientFirstName = model.ClientFirstName;
            user.ClientLastName = model.ClientLastName;
            user.ClientFatherName = model.ClientFatherName;
            user.Phone = model.Phone;
            user.Address = model.Address;
            user.Country = model.Country;

            _context.SaveChanges();

            TempData["SuccessMessage"] = "Профіль успішно оновлено!";
            return RedirectToAction("Index");
        }
    }
}