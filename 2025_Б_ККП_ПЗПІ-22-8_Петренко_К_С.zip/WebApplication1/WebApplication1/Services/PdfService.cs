﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using WebApplication1.Models;

public class PdfService
{
    public byte[] GenerateOrderPdf(List<OrderItemViewModel> items, Order order)
    {
        using (var memoryStream = new MemoryStream())
        {
            var doc = new Document(PageSize.A4.Rotate());
            var writer = PdfWriter.GetInstance(doc, memoryStream);
            doc.Open();

            var baseFont = BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            var fontTitle = new Font(baseFont, 23, Font.BOLD);
            var fontNormal = new Font(baseFont, 17, Font.NORMAL);

            var header1 = new Paragraph("PharmacyGo", fontTitle) { Alignment = Element.ALIGN_CENTER };
            var header2 = new Paragraph("Ваш довідник у світ ліків", fontTitle) { Alignment = Element.ALIGN_CENTER };

            doc.Add(header1);
            doc.Add(header2);
            doc.Add(new Paragraph(" "));
            doc.Add(new Paragraph(" "));

            var orderInfo = new Paragraph($"Замовлення #{order.OrderId}", fontTitle) { Alignment = Element.ALIGN_CENTER };
            doc.Add(orderInfo);
            doc.Add(new Paragraph($"Дата: {order.CartDate?.ToString("dd.MM.yyyy")}", fontNormal));
            doc.Add(new Paragraph(" "));

            var table = new PdfPTable(3);
            table.WidthPercentage = 100;
            table.SetWidths(new float[] { 450f, 100f, 100f });

            table.AddCell(new PdfPCell(new Phrase("Назва препарата", fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });
            table.AddCell(new PdfPCell(new Phrase("Кількість", fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });
            table.AddCell(new PdfPCell(new Phrase("Ціна", fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });

            decimal totalAmount = 0;
            foreach (var item in items)
            {
                table.AddCell(new PdfPCell(new Phrase(item.MedicineName, fontNormal)));
                table.AddCell(new PdfPCell(new Phrase(item.Quantity.ToString(), fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });
                table.AddCell(new PdfPCell(new Phrase(item.TotalPrice.ToString("0.00"), fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });
                totalAmount += item.TotalPrice;
            }

            table.AddCell(new PdfPCell(new Phrase("Сума замовлення:", fontNormal)) { Colspan = 2, HorizontalAlignment = Element.ALIGN_RIGHT });
            table.AddCell(new PdfPCell(new Phrase(totalAmount.ToString("0.00"), fontNormal)) { HorizontalAlignment = Element.ALIGN_CENTER });

            doc.Add(table);
            doc.Close();

            return memoryStream.ToArray();
        }
    }
}
