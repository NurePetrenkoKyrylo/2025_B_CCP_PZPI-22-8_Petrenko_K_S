﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("suppliers")]
public partial class Supplier
{
    [Key]
    [Column("supplier_id")]
    public int SupplierId { get; set; }

    [Column("supplier_name")]
    [StringLength(100)]
    [Unicode(false)]
    public string? SupplierName { get; set; }

    [Column("contact_email")]
    [StringLength(100)]
    [Unicode(false)]
    public string? ContactEmail { get; set; }

    [Column("contact_phone")]
    [StringLength(50)]
    [Unicode(false)]
    public string? ContactPhone { get; set; }

    [Column("country")]
    [StringLength(100)]
    [Unicode(false)]
    public string? Country { get; set; }

    [InverseProperty("Supplier")]
    public virtual ICollection<Medicine> Medicines { get; set; } = new List<Medicine>();
}
