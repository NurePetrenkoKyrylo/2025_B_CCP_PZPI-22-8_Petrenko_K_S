﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("cart")]
public partial class Cart
{
    [Key]
    [Column("cart_id")]
    public int CartId { get; set; }

    [Column("quantity")]
    public int? Quantity { get; set; }

    [Column("totalprice")]
    public int? Totalprice { get; set; }

    [Column("client_id")]
    public int? ClientId { get; set; }

    [Column("medicine_id")]
    public int? MedicineId { get; set; }

    [ForeignKey("ClientId")]
    [InverseProperty("Carts")]
    public virtual Client? Client { get; set; }

    [ForeignKey("MedicineId")]
    [InverseProperty("Carts")]
    public virtual Medicine? Medicine { get; set; }



}
