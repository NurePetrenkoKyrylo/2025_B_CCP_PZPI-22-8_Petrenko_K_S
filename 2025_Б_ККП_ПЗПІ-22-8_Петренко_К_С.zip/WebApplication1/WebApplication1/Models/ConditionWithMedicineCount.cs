﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Keyless]
public partial class ConditionWithMedicineCount
{
    [Column("condition_id")]
    public int ConditionId { get; set; }

    [Column("condition_type")]
    [StringLength(30)]
    [Unicode(false)]
    public string ConditionType { get; set; } = null!;

    [Column("discount")]
    public int? Discount { get; set; }

    [Column("num_of_medicines")]
    public int? NumOfMedicines { get; set; }
}
