﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("orders")]
public partial class Order
{
    [Key]
    [Column("order_id")]
    public int OrderId { get; set; }

    [Column("client_id")]
    public int? ClientId { get; set; }

    [Column("cart_date")]
    public DateOnly? CartDate { get; set; }

    [Column("total_amount")]
    public int? TotalAmount { get; set; }

    [ForeignKey("ClientId")]
    [InverseProperty("Orders")]
    public virtual Client? Client { get; set; }
}
