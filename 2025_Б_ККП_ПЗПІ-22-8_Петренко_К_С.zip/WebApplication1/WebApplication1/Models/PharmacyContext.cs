﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

public partial class PharmacyContext : DbContext
{
    public PharmacyContext()
    {
    }

    public PharmacyContext(DbContextOptions<PharmacyContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Cart> Carts { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<CategoryWithMedicineCount> CategoryWithMedicineCounts { get; set; }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<Condition> Conditions { get; set; }

    public virtual DbSet<ConditionWithMedicineCount> ConditionWithMedicineCounts { get; set; }

    public virtual DbSet<Feedback> Feedbacks { get; set; }

    public virtual DbSet<Medicine> Medicines { get; set; }

    public virtual DbSet<NotificationRequest> NotificationRequests { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<Supplier> Suppliers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("name=DefaultConnection");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.UseCollation("Cyrillic_General_CI_AS");

        modelBuilder.Entity<Cart>(entity =>
        {
            entity.HasKey(e => e.CartId).HasName("PK__cart__2EF52A27E91D0C6F");

            entity.HasOne(d => d.Client).WithMany(p => p.Carts)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__cart__client_id__6C190EBB");

            entity.HasOne(d => d.Medicine).WithMany(p => p.Carts)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__cart__medicine_i__6D0D32F4");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.CategoryId).HasName("PK__categori__D54EE9B4F1A732A2");
        });

        modelBuilder.Entity<CategoryWithMedicineCount>(entity =>
        {
            entity.ToView("category_with_medicine_count");
        });

        modelBuilder.Entity<Client>(entity =>
        {
            entity.HasKey(e => e.ClientId).HasName("PK__client__BF21A4245739F2A7");
        });

        modelBuilder.Entity<Condition>(entity =>
        {
            entity.HasKey(e => e.ConditionId).HasName("PK__conditio__8527AB15F8A4FB39");

            entity.Property(e => e.ConditionId).ValueGeneratedNever();
        });

        modelBuilder.Entity<ConditionWithMedicineCount>(entity =>
        {
            entity.ToView("condition_with_medicine_count");
        });

        modelBuilder.Entity<Feedback>(entity =>
        {
            entity.HasKey(e => e.FeedbackId).HasName("PK__feedback__7A6B2B8C25110C44");

            entity.HasOne(d => d.Client).WithMany(p => p.Feedbacks)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__feedback__client__6E01572D");

            entity.HasOne(d => d.Medicine).WithMany(p => p.Feedbacks)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__feedback__medici__6EF57B66");
        });

        modelBuilder.Entity<Medicine>(entity =>
        {
            entity.HasKey(e => e.MedicineId).HasName("PK__medicine__E7148EBB94EAAE5B");

            entity.HasOne(d => d.Category).WithMany(p => p.Medicines)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__medicine__catego__70DDC3D8");

            entity.HasOne(d => d.Condition).WithMany(p => p.Medicines)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__medicine__condit__6FE99F9F");

            entity.HasOne(d => d.Supplier).WithMany(p => p.Medicines)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__medicine__suppli__71D1E811");
        });

        modelBuilder.Entity<NotificationRequest>(entity =>
        {
            entity.HasKey(e => e.RequestId).HasName("PK__Notifica__18D3B90FCB97FDAA");

            entity.HasOne(d => d.Client).WithMany(p => p.NotificationRequests)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Notificat__clien__72C60C4A");

            entity.HasOne(d => d.Medicine).WithMany(p => p.NotificationRequests)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Notificat__medic__73BA3083");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__orders__465962292E0105B9");

            entity.HasOne(d => d.Client).WithMany(p => p.Orders)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__orders__client_i__74AE54BC");
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity.HasKey(e => e.SupplierId).HasName("PK__supplier__6EE594E833045662");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
