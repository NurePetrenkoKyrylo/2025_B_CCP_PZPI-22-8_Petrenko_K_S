﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("feedback")]
public partial class Feedback
{
    [Key]
    [Column("feedback_id")]
    public int FeedbackId { get; set; }

    [Column("client_id")]
    public int? ClientId { get; set; }

    [Column("medicine_id")]
    public int? MedicineId { get; set; }

    [Column("rating")]
    public int? Rating { get; set; }

    [Column("comment")]
    [StringLength(500)]
    [Unicode(false)]
    public string? Comment { get; set; }

    [Column("feedback_date")]
    public DateOnly? FeedbackDate { get; set; }

    [ForeignKey("ClientId")]
    [InverseProperty("Feedbacks")]
    public virtual Client? Client { get; set; }

    [ForeignKey("MedicineId")]
    [InverseProperty("Feedbacks")]
    public virtual Medicine? Medicine { get; set; }
}
