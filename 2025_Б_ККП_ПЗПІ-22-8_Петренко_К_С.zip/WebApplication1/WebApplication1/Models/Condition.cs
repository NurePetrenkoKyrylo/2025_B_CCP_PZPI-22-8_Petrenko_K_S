﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("conditions")]
public partial class Condition
{
    [Key]
    [Column("condition_id")]
    public int ConditionId { get; set; }

    [Column("condition_type")]
    [StringLength(30)]
    [Unicode(false)]
    public string ConditionType { get; set; } = null!;

    [Column("discount")]
    public int? Discount { get; set; }

    [InverseProperty("Condition")]
    public virtual ICollection<Medicine> Medicines { get; set; } = new List<Medicine>();
}
