﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

public partial class NotificationRequest
{
    [Key]
    [Column("request_id")]
    public int RequestId { get; set; }

    [Column("client_id")]
    public int? ClientId { get; set; }

    [Column("medicine_id")]
    public int? MedicineId { get; set; }

    [Column("request_date")]
    public DateOnly? RequestDate { get; set; }

    [Column("emailSent")]
    public int? EmailSent { get; set; }

    [ForeignKey("ClientId")]
    [InverseProperty("NotificationRequests")]
    public virtual Client? Client { get; set; }

    [ForeignKey("MedicineId")]
    [InverseProperty("NotificationRequests")]
    public virtual Medicine? Medicine { get; set; }
}
