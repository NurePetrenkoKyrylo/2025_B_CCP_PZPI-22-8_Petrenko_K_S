﻿namespace WebApplication1.Models
{
    public class OrderItemViewModel
    {
        public int MedicineId { get; set; }
        public string MedicineName { get; set; }
        public decimal PricePerUnit { get; set; }
        public int Quantity { get; set; }
        public decimal TotalPrice => PricePerUnit * Quantity;


    }
}
