﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class VerifyCodeViewModel
    {
        public string? Email { get; set; }

        [Required(ErrorMessage = "Код обов'язковий")]
        [StringLength(6, MinimumLength = 6, ErrorMessage = "Код повинен містити 6 цифр")]
        public string? Code { get; set; }


    }
}
