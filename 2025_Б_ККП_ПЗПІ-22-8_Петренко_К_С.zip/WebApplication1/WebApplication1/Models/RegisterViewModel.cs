﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Ім’я обов’язкове")]
        [Display(Name = "Ім’я")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Прізвище обов’язкове")]
        [Display(Name = "Прізвище")]
        public string LastName { get; set; }

        [Display(Name = "По батькові")]
        public string? FatherName { get; set; }

        [Display(Name = "Країна")]
        public string? Country { get; set; }

        [Display(Name = "Номер телефону")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Email обов’язковий")]
        [EmailAddress(ErrorMessage = "Некоректний Email")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Display(Name = "Адреса")]
        public string? Address { get; set; }

    }
}
