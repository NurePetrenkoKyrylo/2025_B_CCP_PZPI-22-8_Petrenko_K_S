﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("medicine")]
public partial class Medicine
{
    [Key]
    [Column("medicine_id")]
    public int MedicineId { get; set; }

    [Column("name")]
    [StringLength(100)]
    [Unicode(false)]
    public string Name { get; set; } = null!;

    [Column("manufacturer")]
    [StringLength(100)]
    [Unicode(false)]
    public string? Manufacturer { get; set; }

    [Column("release_year")]
    public int? ReleaseYear { get; set; }

    [Column("form")]
    [StringLength(50)]
    [Unicode(false)]
    public string? Form { get; set; }

    [Column("expiration_date")]
    public DateOnly? ExpirationDate { get; set; }

    [Column("condition_id")]
    public int? ConditionId { get; set; }

    [Column("price")]
    public int? Price { get; set; }

    [Column("category_id")]
    public int? CategoryId { get; set; }

    [Column("in_stock")]
    public int? InStock { get; set; }

    [Column("supplier_id")]
    public int? SupplierId { get; set; }

    [Column("country_of_origin")]
    [StringLength(100)]
    [Unicode(false)]
    public string? CountryOfOrigin { get; set; }

    [InverseProperty("Medicine")]
    public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();

    [ForeignKey("CategoryId")]
    [InverseProperty("Medicines")]
    public virtual Category? Category { get; set; }

    [ForeignKey("ConditionId")]
    [InverseProperty("Medicines")]
    public virtual Condition? Condition { get; set; }

    [InverseProperty("Medicine")]
    public virtual ICollection<Feedback> Feedbacks { get; set; } = new List<Feedback>();

    [InverseProperty("Medicine")]
    public virtual ICollection<NotificationRequest> NotificationRequests { get; set; } = new List<NotificationRequest>();

    [ForeignKey("SupplierId")]
    [InverseProperty("Medicines")]
    public virtual Supplier? Supplier { get; set; }
}
