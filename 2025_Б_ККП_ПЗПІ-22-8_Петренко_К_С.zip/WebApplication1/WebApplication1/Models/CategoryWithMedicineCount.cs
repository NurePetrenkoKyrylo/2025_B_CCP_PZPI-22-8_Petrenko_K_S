﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Keyless]
public partial class CategoryWithMedicineCount
{
    [Column("category_id")]
    public int CategoryId { get; set; }

    [Column("category_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string? CategoryName { get; set; }

    [Column("num_of_medicines")]
    public int? NumOfMedicines { get; set; }
}
