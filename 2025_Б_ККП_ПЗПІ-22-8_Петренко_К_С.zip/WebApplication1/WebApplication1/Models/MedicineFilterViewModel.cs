﻿namespace WebApplication1.Models
{
    public class MedicineFilterViewModel
    {
        public List<Medicine> Medicines { get; set; }

        public List<string> SelectedCountries { get; set; } = new();
        public List<string> SelectedCategories { get; set; } = new();
        public List<string> SelectedForms { get; set; } = new();

        public decimal? PriceFrom { get; set; }
        public decimal? PriceTo { get; set; }

        public string SearchQuery { get; set; }

    }
}
