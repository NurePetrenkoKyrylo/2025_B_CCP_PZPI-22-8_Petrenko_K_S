﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

[Table("client")]
public partial class Client
{
    [Key]
    [Column("client_id")]
    public int ClientId { get; set; }

    [Column("client_first_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string? ClientFirstName { get; set; }

    [Column("client_last_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string? ClientLastName { get; set; }

    [Column("client_father_name")]
    [StringLength(50)]
    [Unicode(false)]
    public string? ClientFatherName { get; set; }

    [Column("country")]
    [StringLength(100)]
    [Unicode(false)]
    public string? Country { get; set; }

    [Column("phone")]
    [StringLength(50)]
    [Unicode(false)]
    public string? Phone { get; set; }

    [Column("email")]
    [StringLength(100)]
    [Unicode(false)]
    public string? Email { get; set; }

    [Column("address")]
    [StringLength(200)]
    [Unicode(false)]
    public string? Address { get; set; }


    [InverseProperty("Client")]
    public virtual ICollection<Cart> Carts { get; set; } = new List<Cart>();

    [InverseProperty("Client")]
    public virtual ICollection<Feedback> Feedbacks { get; set; } = new List<Feedback>();

    [InverseProperty("Client")]
    public virtual ICollection<NotificationRequest> NotificationRequests { get; set; } = new List<NotificationRequest>();

    [InverseProperty("Client")]
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
