﻿/*using WebApplication1.Controllers;

namespace WebApplication1.Models
{
    public class LastOrderData
    {
        public int OrderId { get; set; }
        public List<Controllers.CartItemViewModel> Items { get; set; }
    }
}
*/