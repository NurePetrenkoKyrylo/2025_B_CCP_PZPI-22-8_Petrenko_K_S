﻿namespace CourseWork
{
}

namespace CourseWork
{


    public partial class PharmacyDataSet
    {
    }
}
