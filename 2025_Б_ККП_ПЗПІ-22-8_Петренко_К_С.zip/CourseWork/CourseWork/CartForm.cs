﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CourseWork.PharmacyDataSetTableAdapters;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Collections.ObjectModel;
using System.Collections;
using System.Diagnostics;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Xml.Linq;
using static CourseWork.PharmacyDataSet;
using System.IO;
using Org.BouncyCastle.Crypto.Engines;
using System.Data.Common;

namespace CourseWork
{
    public partial class CartForm : Form
    {
        private int client_id;
        private int medicine_id;
        private DataTable cartDisplayTable = new DataTable();

        public CartForm(int client_id, int medicine_id)
        {
            InitializeComponent();
            this.client_id = client_id;
            this.medicine_id = medicine_id;

            cartDisplayTable.Columns.Add("cart_id", typeof(decimal));
            cartDisplayTable.Columns.Add("namecolumn", typeof(string));
            cartDisplayTable.Columns.Add("medicine_id", typeof(decimal));
            cartDisplayTable.Columns.Add("quantity", typeof(int));
            cartDisplayTable.Columns.Add("totalPrice", typeof(decimal));
            cartDisplayTable.Columns.Add("client_id", typeof(decimal));

            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.ReadOnly = false;

            dataGridView2.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView2.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView2.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView2.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            dataGridView2.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 12, FontStyle.Regular);
            dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView2.ReadOnly = false;
        }

        private void CartForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.NotificationRequests". При необходимости она может быть перемещена или удалена.
            this.notificationRequestsTableAdapter.Fill(this.pharmacyDataSet.NotificationRequests);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.medicine". При необходимости она может быть перемещена или удалена.
            this.medicineTableAdapter.FillBy2(this.pharmacyDataSet.medicine);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.orders". При необходимости она может быть перемещена или удалена.
            this.ordersTableAdapter.Fill(this.pharmacyDataSet.orders);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.pharmacyDataSet.client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.pharmacyDataSet.client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.cart". При необходимости она может быть перемещена или удалена.
            this.cartTableAdapter.FillBy(this.pharmacyDataSet.cart);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.cart". При необходимости она может быть перемещена или удалена.
            dataGridView1.AutoGenerateColumns = true;
            dataGridView2.DataSource = cartDisplayTable;

            dataGridView1.Columns["medicineidDataGridViewTextBoxColumn2"].Visible = false;
            dataGridView1.Columns["categoryidDataGridViewTextBoxColumn"].Visible = false;
            dataGridView1.Columns["conditionidDataGridViewTextBoxColumn"].Visible = false;
            dataGridView1.Columns["dataGridViewTextBoxColumn4"].Visible = false;

            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].HeaderText = "Назва препарата";
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].HeaderText = "Виробник";
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].HeaderText = "Рік випуску";
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].HeaderText = "Форма";
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].HeaderText = "Строк придатності";
            dataGridView1.Columns["supplier_name"].HeaderText = "Поставщик";
            dataGridView1.Columns["dataGridViewTextBoxColumn5"].HeaderText = "Країна виробник";
            dataGridView1.Columns["condition_type"].HeaderText = "Стан";
            dataGridView1.Columns["priceDataGridViewTextBoxColumn"].HeaderText = "Ціна";
            dataGridView1.Columns["category_name"].HeaderText = "Категорія препарата";
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].HeaderText = "В наявності";

            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].Visible = true;
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].Width = 250;
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].Width = 150;
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].Width = 100;
            dataGridView1.Columns["condition_type"].Width = 200;
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].Width = 100;
            dataGridView1.Columns["category_name"].Width = 200;
            dataGridView1.Columns["dataGridViewTextBoxColumn5"].Width = 100;
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].Width = 120;
            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].Width = 300;

            dataGridView2.Columns["namecolumn"].HeaderText = "Назва монети";
            dataGridView2.Columns["quantityDataGridViewTextBoxColumn"].HeaderText = "Кількість";
            dataGridView2.Columns["dataGridViewTextBoxColumn2"].HeaderText = "Ціна";
            dataGridView2.Columns["namecolumn"].Width = 200;
            dataGridView2.Columns["dataGridViewTextBoxColumn1"].Visible = false;
            dataGridView2.Columns["dataGridViewTextBoxColumn3"].Visible = false;
            dataGridView2.Columns["medicineidDataGridViewTextBoxColumn"].Visible = false;

            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].DisplayIndex = 0;
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].DisplayIndex = 1;
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].DisplayIndex = 2;
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].DisplayIndex = 3;
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].DisplayIndex = 4;
            dataGridView1.Columns["supplier_name"].DisplayIndex = 5;
            dataGridView1.Columns["dataGridViewTextBoxColumn5"].DisplayIndex = 6;
            dataGridView1.Columns["condition_type"].DisplayIndex = 7;
            dataGridView1.Columns["priceDataGridViewTextBoxColumn"].DisplayIndex = 8;
            dataGridView1.Columns["category_name"].DisplayIndex = 9;
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].DisplayIndex = 10;
            dataGridView1.Refresh();
        }

        private decimal CalculateTotalOrderPrice(DataGridView dataGridView)
        {
            decimal totalOrderPrice = 0;
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells["dataGridViewTextBoxColumn2"].Value != null && row.Cells["dataGridViewTextBoxColumn2"].Value != DBNull.Value)
                {
                    totalOrderPrice += Convert.ToDecimal(row.Cells["dataGridViewTextBoxColumn2"].Value);
                }
            }

            return totalOrderPrice;
        }


        private void SaveNotificationRequest()
        {
            try
            {
                clientTableAdapter clientsAdapter = new clientTableAdapter();
                medicineTableAdapter medicineAdapter = new medicineTableAdapter();
                NotificationRequestsTableAdapter notificationAdapter = new NotificationRequestsTableAdapter();

                int selectedClientID = GetSelectedClientID();
                int selectedMedicineID = GetSelectedMedicineID();
                int emailSent = 0;

                notificationAdapter.Insert(selectedClientID, selectedMedicineID, DateTime.Now, emailSent);

                pharmacyDataSet.AcceptChanges();

                MessageBox.Show("Повідомлення буде надіслано, як препарат з'явиться в наявності.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Помилка: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetSelectedClientID()
        {
            return client_id;
        }

        private int GetSelectedMedicineID()
        {
            return (int)dataGridView1.SelectedRows[0].Cells["medicineidDataGridViewTextBoxColumn2"].Value;
        }

        private int nextCartId = 10;

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string name = selectedRow.Cells["nameDataGridViewTextBoxColumn"].Value.ToString();
                int cart_id = nextCartId++;


                if (int.TryParse(textBox1.Text, out int quantity))
                {
                    decimal pricePerMedicine = Convert.ToDecimal(selectedRow.Cells["priceDataGridViewTextBoxColumn"].Value);
                    decimal totalPrice = quantity * pricePerMedicine;
                    int medicine_id = Convert.ToInt32(selectedRow.Cells["medicineidDataGridViewTextBoxColumn2"].Value);

                    int availableQuantity = Convert.ToInt32(selectedRow.Cells["inStockDataGridViewTextBoxColumn"].Value);

                    if (availableQuantity == 0)
                    {
                        var result = MessageBox.Show("На даний момент немає доступних ліків у наявності. Бажаєте отримати повідомлення, коли препарат знову з'являться?", "Немає доступних ліків", MessageBoxButtons.YesNo);

                        if (result == DialogResult.Yes)
                        {
                            SaveNotificationRequest();
                        }

                        return;
                    }

                    if (quantity > availableQuantity)
                    {
                        MessageBox.Show("Недостатня кількість ліків в наявності.");
                        return;
                    }

                    DataRow newRow = cartDisplayTable.NewRow();
                    newRow["cart_id"] = cart_id;
                    newRow["namecolumn"] = name;
                    newRow["medicine_id"] = medicine_id;
                    newRow["quantity"] = quantity;
                    newRow["totalPrice"] = totalPrice;
                    newRow["client_id"] = this.client_id;
                    cartDisplayTable.Rows.Add(newRow);

                    int in_stock = availableQuantity - quantity;
                    selectedRow.Cells["inStockDataGridViewTextBoxColumn"].Value = in_stock;

                    dataGridView2.DataSource = cartDisplayTable;

                }
                else
                {
                    MessageBox.Show("Введіть коректну кількість.");
                }
            }
            else
            {
                MessageBox.Show("Виберіть монету для додавання до кошику.");
            }
        }

        private void button_done_Click(object sender, EventArgs e)
        {
            DialogResult result = DialogResult.No;

            if (this.client_id != -1)
            {
                if (dataGridView2.Rows.Count > 0)
                {
                    // Найти максимальный cart_id и начать с него + 1
                    int maxCartId = 0;
                    foreach (DataRow row in pharmacyDataSet.cart.Rows)
                    {
                        int id = Convert.ToInt32(row["cart_id"]);
                        if (id > maxCartId)
                            maxCartId = id;
                    }

                    int nextCartId = maxCartId + 1;

                    foreach (DataRow displayRow in cartDisplayTable.Rows)
                    {
                        DataRow newCartRow = pharmacyDataSet.cart.NewRow();

                        newCartRow["cart_id"] = nextCartId++;
                        newCartRow["medicine_id"] = displayRow["medicine_id"];
                        newCartRow["quantity"] = displayRow["quantity"];
                        newCartRow["totalPrice"] = displayRow["totalPrice"];
                        newCartRow["client_id"] = this.client_id;

                        pharmacyDataSet.cart.Rows.Add(newCartRow);
                    }

                    cartTableAdapter.Update(pharmacyDataSet.cart);

                    DataRow newOrderRow = pharmacyDataSet.orders.NewRow();

                    //int order_id = pharmacyDataSet.orders.Rows.Count + 1;
                    DateTime cart_date = DateTime.Now;

                    decimal total_amount = CalculateTotalOrderPrice(dataGridView2);

                    newOrderRow["cart_date"] = cart_date;
                    newOrderRow["total_amount"] = total_amount;
                    newOrderRow["client_id"] = this.client_id;

                    pharmacyDataSet.orders.Rows.Add(newOrderRow);

                    ordersTableAdapter.Update(pharmacyDataSet.orders);


                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        int medicine_id = Convert.ToInt32(row.Cells["medicineidDataGridViewTextBoxColumn2"].Value);
                        int in_stock = Convert.ToInt32(row.Cells["instockDataGridViewTextBoxColumn"].Value);

                        try
                        {
                            medicineTableAdapter.UpdateQuery2(in_stock, medicine_id);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Помилка: " + ex.Message);
                        }
                    }

                    pharmacyDataSet.AcceptChanges();

                    result = MessageBox.Show("Бажаєте зберегти дані про замовлення?", "Підтвердження", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                }
                else
                {
                    MessageBox.Show("Ваша кошик порожній. Додайте товари перед завершенням замовлення.", "Інформація", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                if (result == DialogResult.Yes)
                {
                    Document doc = new Document(PageSize.A4.Rotate());

                    BaseFont arial = BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
                    iTextSharp.text.Font f_15_bold = new iTextSharp.text.Font(arial, 23, iTextSharp.text.Font.BOLD);
                    iTextSharp.text.Font f_12_normal = new iTextSharp.text.Font(arial, 17, iTextSharp.text.Font.NORMAL);

                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
                    saveFileDialog.Title = "Save PDF File";
                    saveFileDialog.FileName = "Чек заказа" + ".pdf";

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = saveFileDialog.FileName;

                        FileStream os = new FileStream(filePath, FileMode.Create);

                        using (os)
                        {
                            PdfWriter.GetInstance(doc, os);
                            doc.Open();

                            Paragraph header1 = new Paragraph("PharmacyGo", f_15_bold);
                            Paragraph header2 = new Paragraph("Ваш довідник у світ ліків", f_15_bold);
                            Paragraph header3 = new Paragraph("Телефон: +380508043444", f_15_bold);
                            Paragraph header4 = new Paragraph("Адреса: Вул. Соціалістична 23, Буд. А", f_15_bold);

                            header1.Alignment = Element.ALIGN_CENTER;
                            header2.Alignment = Element.ALIGN_CENTER;
                            header3.Alignment = Element.ALIGN_LEFT;
                            header4.Alignment = Element.ALIGN_LEFT;

                            doc.Add(header1);
                            doc.Add(header2);
                            doc.Add(header3);
                            doc.Add(header4);
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));


                            Paragraph headers1 = new Paragraph("Замовлення", f_15_bold);
                            headers1.Alignment = Element.ALIGN_CENTER;
                            doc.Add(headers1);

                            PdfPTable medicineTable = new PdfPTable(3); // Adjust the number of columns accordingly
                            decimal totalAmount = 0;

                            PdfPCell nameHeaderCell = new PdfPCell(new Phrase("Назва препарата", f_12_normal)) { HorizontalAlignment = Element.ALIGN_CENTER };
                            PdfPCell quantityHeaderCell = new PdfPCell(new Phrase("Кількість", f_12_normal)) { HorizontalAlignment = Element.ALIGN_CENTER };
                            PdfPCell priceHeaderCell = new PdfPCell(new Phrase("Ціна", f_12_normal)) { HorizontalAlignment = Element.ALIGN_CENTER };

                            medicineTable.AddCell(nameHeaderCell);
                            medicineTable.AddCell(quantityHeaderCell);
                            medicineTable.AddCell(priceHeaderCell);


                            foreach (DataGridViewRow row in dataGridView2.Rows)
                            {
                                PdfPCell nameCell = new PdfPCell(new Phrase(row.Cells["namecolumn"].Value?.ToString() ?? "", f_12_normal));
                                PdfPCell quantityCell = new PdfPCell(new Phrase(row.Cells["quantityDataGridViewTextBoxColumn"].Value?.ToString() ?? "", f_12_normal));
                                PdfPCell priceCell = new PdfPCell(new Phrase(row.Cells["dataGridViewTextBoxColumn2"].Value?.ToString() ?? "", f_12_normal));

                                medicineTable.AddCell(nameCell);
                                medicineTable.AddCell(quantityCell);
                                medicineTable.AddCell(priceCell);

                                if (row.Cells["dataGridViewTextBoxColumn2"].Value != null && decimal.TryParse(row.Cells["dataGridViewTextBoxColumn2"].Value.ToString(), out decimal price))
                                {
                                    totalAmount += price;
                                }
                            }

                            PdfPCell totalAmountCell = new PdfPCell(new Phrase("Сума заказу:", f_12_normal));
                            totalAmountCell.Colspan = 2;
                            totalAmountCell.HorizontalAlignment = Element.ALIGN_RIGHT;
                            medicineTable.AddCell(totalAmountCell);

                            PdfPCell totalAmountValueCell = new PdfPCell(new Phrase(totalAmount.ToString(), f_12_normal));
                            totalAmountValueCell.HorizontalAlignment = Element.ALIGN_CENTER;
                            medicineTable.AddCell(totalAmountValueCell);

                            medicineTable.WidthPercentage = 100;
                            float[] medicineTableWidths = new float[] { 450f, 100f, 100 };
                            medicineTable.SetWidths(medicineTableWidths);
                            medicineTable.SpacingBefore = 20;
                            doc.Add(medicineTable);

                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));
                            doc.Add(new Paragraph(" "));

                            PdfPTable tableHeader = new PdfPTable(2);
                            tableHeader.WidthPercentage = 100;
                            tableHeader.SetWidths(new float[] { 100f, 100f });

                            PdfPCell cellDate = new PdfPCell(new Phrase("Дата: " + DateTime.Now.ToString("dd/MM/yyyy"), f_12_normal));
                            cellDate.Border = iTextSharp.text.Rectangle.NO_BORDER;
                            cellDate.HorizontalAlignment = Element.ALIGN_LEFT;

                            PdfPCell cellShopName = new PdfPCell(new Phrase("PharmacyGo", f_12_normal));
                            cellShopName.Border = iTextSharp.text.Rectangle.NO_BORDER;
                            cellShopName.HorizontalAlignment = Element.ALIGN_RIGHT;

                            tableHeader.AddCell(cellDate);
                            tableHeader.AddCell(cellShopName);

                            doc.Add(tableHeader);

                            doc.Close();
                            System.Diagnostics.Process.Start(filePath);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите клиента из таблицы перед созданием заказа.", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView2.SelectedRows;

            foreach (DataGridViewRow row in selectedRows)
            {
                int rowIndex = row.Index;
                int cart_id = Convert.ToInt32(cartDisplayTable.Rows[rowIndex]["cart_id"]);
                int medicine_id = Convert.ToInt32(cartDisplayTable.Rows[rowIndex]["medicine_id"]);
                int quantity = Convert.ToInt32(cartDisplayTable.Rows[rowIndex]["quantity"]);

                DataRow[] medicineRows = pharmacyDataSet.medicine.Select($"medicine_id = {medicine_id}");

                if (medicineRows.Length > 0)
                {
                    int currentInStock = Convert.ToInt32(medicineRows[0]["in_stock"]);
                    int updatedInStock = currentInStock + quantity;

                    medicineRows[0]["in_stock"] = updatedInStock;
                }

                cartDisplayTable.Rows.RemoveAt(rowIndex);
            }


            dataGridView2.DataSource = null;
            dataGridView2.DataSource = cartDisplayTable;
        }

        
    }
}
