﻿using iTextSharp.text.pdf;
using iTextSharp.text;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class AdminFom : Form
    {
        private int medicine_id;
        public AdminFom()
        {
            InitializeComponent();
            lowerLimitTextBox.Text = "1";
            upperLimitTextBox.Text = "1000000";
            button6.Visible = false;
            button7.Visible = false;
            searchField.TextChanged += searchField_TextChanged;
            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.ReadOnly = false;
            button9.Visible = false;
        }
        private const int WideFormWidth = 1310;
        private const int NarrowFormWidth = 1040;


        Point lastPoint;
        private void AdminFom_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void AdminFom_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void closeButton_MouseEnter(object sender, EventArgs e)
        {
            closeButton.ForeColor = Color.Green;
        }

        private void closeButton_MouseLeave(object sender, EventArgs e)
        {
            closeButton.ForeColor = Color.White;
        }

        private string currentTable = "medicine";

        private void button1_Click(object sender, EventArgs e)
        {
            this.Width = WideFormWidth;
            panel5.Visible = true;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = medicineBindingSource;
            this.medicineTableAdapter.FillBy2(this.pharmacyDataSet.medicine);
            label1.Text = "Ліки";
            currentTable = "medicine";
            button6.Visible = false;
            button8.Visible = true;
            button7.Visible = false;
            button9.Visible = false;
            button10.Visible = true;
            dataGridView1.Columns["medicine_id"].Visible = false;
            dataGridView1.Columns["category_id"].Visible = false;
            dataGridView1.Columns["condition_id"].Visible = false;
            dataGridView1.Columns["supplier_id"].Visible = false;
            dataGridView1.Columns["name"].HeaderText = "Назва препарата";
            dataGridView1.Columns["manufacturer"].HeaderText = "Виробник";
            dataGridView1.Columns["release_year"].HeaderText = "Рік випуску";
            dataGridView1.Columns["form"].HeaderText = "Форма";
            dataGridView1.Columns["expiration_date"].HeaderText = "Строк придатності";
            dataGridView1.Columns["supplier_name"].HeaderText = "Постачальник";
            dataGridView1.Columns["country_of_origin"].HeaderText = "Країна виробник";
            dataGridView1.Columns["condition_type"].HeaderText = "Стан";
            dataGridView1.Columns["price"].HeaderText = "Ціна";
            dataGridView1.Columns["category_name"].HeaderText = "Категорія препарата";
            dataGridView1.Columns["in_stock"].HeaderText = "В наявності";

            dataGridView1.Columns["name"].Visible = true;
            dataGridView1.Columns["manufacturer"].Width = 400;
            dataGridView1.Columns["release_year"].Width = 150;
            dataGridView1.Columns["form"].Width = 100;
            dataGridView1.Columns["condition_type"].Width = 200;
            dataGridView1.Columns["in_stock"].Width = 100;
            dataGridView1.Columns["category_name"].Width = 200;
            dataGridView1.Columns["country_of_origin"].Width = 250;
            dataGridView1.Columns["expiration_date"].Width = 120;
            dataGridView1.Columns["name"].Width = 200;

            dataGridView1.Columns["name"].DisplayIndex = 0;
            dataGridView1.Columns["manufacturer"].DisplayIndex = 1;
            dataGridView1.Columns["release_year"].DisplayIndex = 2;
            dataGridView1.Columns["form"].DisplayIndex = 3;
            dataGridView1.Columns["expiration_date"].DisplayIndex = 4;
            dataGridView1.Columns["category_name"].DisplayIndex = 5;
            dataGridView1.Columns["supplier_name"].DisplayIndex = 6;
            dataGridView1.Columns["condition_type"].DisplayIndex = 7;
            dataGridView1.Columns["price"].DisplayIndex = 8;
            dataGridView1.Columns["country_of_origin"].DisplayIndex = 9;
            dataGridView1.Columns["in_stock"].DisplayIndex = 10;
            dataGridView1.Refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Width = NarrowFormWidth;
            panel5.Visible = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = categoriesBindingSource;
            this.categoriesTableAdapter.FillBy2(this.pharmacyDataSet.categories);
            label1.Text = "Категорії";
            currentTable = "categories";
            button6.Visible = false;
            button8.Visible = false;
            deleteButton.Visible = false;
            button7.Visible = false;
            button9.Visible = false;
            button10.Visible = true;
            dataGridView1.Columns["category_id"].Visible = false;
            dataGridView1.Columns["category_name"].HeaderText = "Назва категорії";
            dataGridView1.Columns["num_of_medicines"].HeaderText = "Кількість лік у категорії";
            dataGridView1.Columns["category_name"].Width = 350;
            dataGridView1.Columns["num_of_medicines"].Width = 225;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Width = NarrowFormWidth;
            panel5.Visible = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = conditionsBindingSource;
            this.conditionsTableAdapter.FillBy2(this.pharmacyDataSet.conditions);
            label1.Text = "Стан";
            currentTable = "conditions";
            button6.Visible = true;
            deleteButton.Visible = false;
            addButton.Visible = false;
            updateButton.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            button10.Visible = true;
            dataGridView1.Columns["condition_id"].Visible = false;
            dataGridView1.Columns["condition_type"].HeaderText = "Стан";
            dataGridView1.Columns["discount"].HeaderText = "Знижка";
            dataGridView1.Columns["num_of_medicines"].HeaderText = "Кількість ліків";
            dataGridView1.Columns["num_of_medicines"].Width = 150;
            dataGridView1.Columns["condition_type"].Width = 355;
            dataGridView1.Columns["discount"].Width = 220;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Width = NarrowFormWidth;
            panel5.Visible = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = clientBindingSource;
            this.clientTableAdapter.FillBy1(this.pharmacyDataSet.client);
            label1.Text = "Клієнти";
            currentTable = "client";
            button6.Visible = false;
            addButton.Visible = true;
            updateButton.Visible = true;
            deleteButton.Visible = true;
            button7.Visible = true;
            button8.Visible = false;
            button9.Visible = true;
            button10.Visible = false;
            dataGridView1.Columns["ПІБ клієнта"].Width = 350;
            dataGridView1.Columns["country"].Width = 250;
            dataGridView1.Columns["address"].Width = 250;
            dataGridView1.Columns["email"].Width = 200;
            dataGridView1.Columns["phone"].Width = 170;
            dataGridView1.Columns["client_id"].Visible = false;
            dataGridView1.Columns["client_first_name"].Visible = false;
            dataGridView1.Columns["client_last_name"].Visible = false;
            dataGridView1.Columns["client_father_name"].Visible = false;
            dataGridView1.Columns["address"].HeaderText = "Адреса";
            dataGridView1.Columns["phone"].HeaderText = "Номер телефону";
            dataGridView1.Columns["email"].HeaderText = "Електронна пошта";
            dataGridView1.Columns["country"].HeaderText = "Країна";
            dataGridView1.Columns["ПІБ клієнта"].DisplayIndex = 0;
            dataGridView1.Columns["country"].DisplayIndex = 1;
            dataGridView1.Columns["phone"].DisplayIndex = 2;
            dataGridView1.Columns["email"].DisplayIndex = 3;
            dataGridView1.Columns["address"].DisplayIndex = 4;
            dataGridView1.Refresh();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var stat = new StatForm();
            stat.ShowDialog();
            button9.Visible = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Width = NarrowFormWidth;
            panel5.Visible = false;
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = suppliersBindingSource;
            this.suppliersTableAdapter.FillBy(this.pharmacyDataSet.suppliers);
            label1.Text = "Постачальники";
            currentTable = "suppliers";
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            dataGridView1.Columns["supplier_id"].Visible = false;
            dataGridView1.Columns["supplier_name"].Visible = false;
            dataGridView1.Columns["contact_email"].Visible = false;
            dataGridView1.Columns["contact_phone"].Visible = false;
            dataGridView1.Columns["country"].Visible = false;
            dataGridView1.Columns["Постачальник"].Width = 250;
            dataGridView1.Columns["Країна"].Width = 150;
            dataGridView1.Columns["Номер телефону"].Width = 150;
            dataGridView1.Columns["Електронна пошта"].Width = 230;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            switch (currentTable)
            {
                case "medicine":
                    var edt = new MedicineForm();
                    edt.ShowDialog();
                    medicineTableAdapter.FillBy2(pharmacyDataSet.medicine);
                    pharmacyDataSet.AcceptChanges();
                    break;

                case "categories":
                    var col = new CategoriesForm();
                    col.ShowDialog();
                    categoriesTableAdapter.Fill(pharmacyDataSet.categories);
                    pharmacyDataSet.AcceptChanges();
                    break;

                case "client":
                    var cl = new ClientsForm();
                    cl.ShowDialog();
                    clientTableAdapter.FillBy1(pharmacyDataSet.client);
                    pharmacyDataSet.AcceptChanges();
                    break;

                case "suppliers":
                    var edd = new SuppliersForm();
                    edd.ShowDialog();
                    suppliersTableAdapter.FillBy(pharmacyDataSet.suppliers);
                    pharmacyDataSet.AcceptChanges();
                    break;
            }
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            switch (currentTable)
            {
                case "medicine":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        medicineTableAdapter.DeleteQuery(
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        medicineTableAdapter.Fill(pharmacyDataSet.medicine);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть монету для видалення.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;

                case "client":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        clientTableAdapter.DeleteQuery(
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        clientTableAdapter.FillBy1(pharmacyDataSet.client);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть клієнта для видалення.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;

                case "categories":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        categoriesTableAdapter.DeleteQuery(
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        categoriesTableAdapter.Fill(pharmacyDataSet.categories);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть колекцію для видалення.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;

                case "suppliers":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        suppliersTableAdapter.DeleteQuery(
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        suppliersTableAdapter.FillBy(pharmacyDataSet.suppliers);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть колекціонера для видалення.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            switch (currentTable)
            {
                case "medicine":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        var st = new PharmacyDataSet.medicineDataTable();
                        medicineTableAdapter.FillBy(st, Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        var row = st.Rows[0];

                        int medicineId = Convert.ToInt32(row["medicine_id"]);
                        string name = row["name"].ToString();
                        string manufacturer = row["manufacturer"].ToString();
                        int releaseYear = SafeToInt(row["release_year"]);
                        string form = row["form"].ToString();
                        DateTime expirationDate = SafeToDate(row["expiration_date"]);
                        int categoryId = SafeToInt(row["category_id"]);
                        int supplierId = SafeToInt(row["supplier_id"]);
                        int conditionId = SafeToInt(row["condition_id"]);
                        int price = SafeToInt(row["price"]);
                        string country = row["country_of_origin"].ToString();
                        int inStock = SafeToInt(row["in_stock"]);


                        var edt = new MedicineForm(
                            id: medicineId,
                            name: name,
                            manufacturer: manufacturer,
                            releaseYear: releaseYear,
                            form: form,
                            expirationDate: expirationDate,
                            categoryId: categoryId,
                            supplierId: supplierId,
                            conditionId: conditionId,
                            price: price,
                            countryOfOrigin: country,
                            inStock: inStock
                        );


                        int SafeToInt(object val) => int.TryParse(val?.ToString(), out var i) ? i : 0;
                        DateTime SafeToDate(object val) => DateTime.TryParse(val?.ToString(), out var dt) ? dt : DateTime.MinValue;


                        edt.ShowDialog();
                        medicineTableAdapter.FillBy2(pharmacyDataSet.medicine);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть монету для редагування.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;


                case "categories":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        var cln = new PharmacyDataSet.categoriesDataTable();
                        categoriesTableAdapter.FillBy(cln,
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        object[] rows = cln.Rows[0].ItemArray;
                        var col = new CategoriesForm(
                        Convert.ToInt32(rows[0]),
                        rows[1].ToString(),
                        Convert.ToInt32(rows[2])
                        );
                        col.ShowDialog();
                        categoriesTableAdapter.Fill(pharmacyDataSet.categories);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть колекцію для редагування.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;


                case "client":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        var cnt = new PharmacyDataSet.clientDataTable();
                        clientTableAdapter.FillBy(cnt,
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        object[] rowss = cnt.Rows[0].ItemArray;
                        var cl = new ClientsForm(
                        Convert.ToInt32(rowss[0]),
                        rowss[1].ToString(),
                        rowss[2].ToString(),
                        rowss[3].ToString(),
                        rowss[4].ToString(),
                        rowss[5].ToString(),
                        rowss[6].ToString(),
                        rowss[7].ToString());
                        cl.ShowDialog();
                        clientTableAdapter.FillBy1(pharmacyDataSet.client);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть клієнта для редагування.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;

                case "suppliers":
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        var cll = new PharmacyDataSet.suppliersDataTable();
                        suppliersTableAdapter.FillBy1(cll,
                        Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                        object[] rowess = cll.Rows[0].ItemArray;
                        var edd = new SuppliersForm(
                        Convert.ToInt32(rowess[0]),
                        rowess[1].ToString(),
                        rowess[2].ToString(),
                        rowess[3].ToString(),
                        rowess[4].ToString());
                        edd.ShowDialog();
                        suppliersTableAdapter.FillBy(pharmacyDataSet.suppliers);
                        pharmacyDataSet.AcceptChanges();
                    }
                    else
                    {
                        MessageBox.Show("Спочатку виберіть колекціонера для редагування.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int client_id = -1; // Инициализация значения по умолчанию

            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                client_id = Convert.ToInt32(selectedRow.Cells["client_id"].Value);
            }

            if (client_id != -1)
            {
                var cart = new CartForm(client_id, medicine_id);
                cart.ShowDialog();
            }
            else
            {
                MessageBox.Show("Спочатку виберіть клієнта для замовлення.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var cnd = new PharmacyDataSet.conditionsDataTable();
                conditionsTableAdapter.FillBy(cnd,
                Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value));
                object[] rowes = cnd.Rows[0].ItemArray;
                var con = new CondForm(
                Convert.ToInt32(rowes[0]),
                rowes[1].ToString(),
                Convert.ToInt32(rowes[2])
                );
                con.ShowDialog();
                conditionsTableAdapter.Fill(pharmacyDataSet.conditions);
                pharmacyDataSet.AcceptChanges();
            }
            else
            {
                MessageBox.Show("Спочатку виберіть стан для редагування.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int client_id = Convert.ToInt32(selectedRow.Cells["client_id"].Value);

                OrderForm orderForm = new OrderForm(client_id);
                orderForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Спочатку виберіть клієнта для перегяду замовленнь.", "Увага", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private bool filterByCountry1 = false;
        private bool filterByCountry2 = false;
        private bool filterByCountry3 = false;
        private bool filterByCountry4 = false;
        private bool filterByCountry5 = false;
        private bool filterByCountry6 = false;

        private bool filterByCategorie1 = false;
        private bool filterByCategorie2 = false;
        private bool filterByCategorie3 = false;
        private bool filterByCategorie4 = false;
        private bool filterByCategorie5 = false;

        private bool filterByForm1 = false;
        private bool filterByForm2 = false;
        private bool filterByForm3 = false;

        private decimal lowerLimit;
        private decimal upperLimit;

        private void searchField_TextChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            DataView dv = new DataView(pharmacyDataSet.Tables["medicine"]);
            StringBuilder filterExpression = new StringBuilder();

            if (filterByCountry1 || filterByCountry2 || filterByCountry3 || filterByCountry4 || filterByCountry5 || filterByCountry6)
            {
                filterExpression.Append("(");

                if (filterByCountry1)
                {
                    filterExpression.Append("country_of_origin = 'США'");
                }

                if (filterByCountry2)
                {
                    if (filterByCountry1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("country_of_origin = 'Китай'");
                }

                if (filterByCountry3)
                {
                    if (filterByCountry1 || filterByCountry2)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("country_of_origin = 'Швейцарія'");

                }

                if (filterByCountry4)
                {
                    if (filterByCountry1 || filterByCountry2 || filterByCountry3)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("country_of_origin = 'Німеччина'");

                }

                if (filterByCountry5)
                {
                    if (filterByCountry1 || filterByCountry2 || filterByCountry3 || filterByCountry4)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("country_of_origin = 'Великобританія'");

                }

                if (filterByCountry6)
                {
                    if (filterByCountry1 || filterByCountry2 || filterByCountry3 || filterByCountry4 || filterByCountry5)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("country_of_origin = 'Японія'");

                }

                filterExpression.Append(")");
            }

            if (filterByCategorie1 || filterByCategorie2 || filterByCategorie3 || filterByCategorie4 || filterByCategorie5)
            {
                if (filterExpression.Length > 0)
                    filterExpression.Append(" AND ");

                filterExpression.Append("(");

                if (filterByCategorie1)
                {
                    filterExpression.Append("category_name = 'Противірусні препарати'");
                }

                if (filterByCategorie2)
                {
                    if (filterByCategorie1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("category_name = 'Антибактеріальні препарати'");
                }

                if (filterByCategorie3)
                {
                    if (filterByCategorie1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("category_name = 'Гормони'");
                }

                if (filterByCategorie4)
                {
                    if (filterByCategorie1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("category_name = 'Діагностичні засоби'");
                }

                if (filterByCategorie5)
                {
                    if (filterByCategorie1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("category_name = 'Протизапальні препарати'");
                }

                filterExpression.Append(")");
            }

            if (filterByForm1 || filterByForm2 || filterByForm3)
            {
                if (filterExpression.Length > 0)
                    filterExpression.Append(" AND ");

                filterExpression.Append("(");

                if (filterByForm1)
                {
                    filterExpression.Append("form = 'Пігулки'");
                }

                if (filterByForm2)
                {
                    if (filterByForm1)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("form = 'Спрей'");
                }

                if (filterByForm3)
                {
                    if (filterByForm1 || filterByForm2)
                        filterExpression.Append(" OR ");
                    filterExpression.Append("form = 'Ампули'");
                }

                filterExpression.Append(")");
            }

            if (!string.IsNullOrWhiteSpace(lowerLimitTextBox.Text) || !string.IsNullOrWhiteSpace(upperLimitTextBox.Text))
            {
                if (filterExpression.Length > 0)
                    filterExpression.Append(" AND ");

                decimal lowerLimit, upperLimit;

                if (!decimal.TryParse(lowerLimitTextBox.Text, out lowerLimit))
                {
                    lowerLimit = 1;
                }

                if (!decimal.TryParse(upperLimitTextBox.Text, out upperLimit))
                {
                    upperLimit = 1000000;
                }

                filterExpression.Append($"price >= {lowerLimit} AND price <= {upperLimit}");
            }

            if (!string.IsNullOrWhiteSpace(searchField.Text))
            {
                if (filterExpression.Length > 0)
                    filterExpression.Append(" AND ");

                string columnName = "name";
                filterExpression.Append($"{columnName} LIKE '%{searchField.Text}%'");
            }

            if (filterExpression.Length > 0)
            {
                dv.RowFilter = filterExpression.ToString();
            }

            dataGridView1.DataSource = dv;
        }

        private void countryFilterCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry1 = checkBox.Checked;
            filterByCountry2 = checkBox1.Checked;
            filterByCountry3 = checkBox2.Checked;
            filterByCountry4 = checkBox15.Checked;
            filterByCountry5 = checkBox16.Checked;
            filterByCountry6 = checkBox17.Checked;
            ApplyFilters();
        }

        private void categorieFilterCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie1 = checkBox3.Checked;
            filterByCategorie2 = checkBox4.Checked;
            filterByCategorie3 = checkBox18.Checked;
            filterByCategorie4 = checkBox19.Checked;
            filterByCategorie5 = checkBox20.Checked;
            ApplyFilters();
        }

        private void formlFilterCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            filterByForm1 = checkBox7.Checked;
            filterByForm2 = checkBox6.Checked;
            filterByForm3 = checkBox5.Checked;
            ApplyFilters();
        }

        private void priceFilterTextBox_TextChanged(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void AdminFom_Load_1(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.feedback". При необходимости она может быть перемещена или удалена.
            this.feedbackTableAdapter.Fill(this.pharmacyDataSet.feedback);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.pharmacyDataSet.client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.conditions". При необходимости она может быть перемещена или удалена.
            this.conditionsTableAdapter.Fill(this.pharmacyDataSet.conditions);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.suppliers". При необходимости она может быть перемещена или удалена.
            this.suppliersTableAdapter.Fill(this.pharmacyDataSet.suppliers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.categories". При необходимости она может быть перемещена или удалена.
            this.categoriesTableAdapter.Fill(this.pharmacyDataSet.categories);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.medicine". При необходимости она может быть перемещена или удалена.
            this.medicineTableAdapter.FillBy2(this.pharmacyDataSet.medicine);
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.Columns["medicineidDataGridViewTextBoxColumn"].Visible = false;
            dataGridView1.Columns["categoryidDataGridViewTextBoxColumn"].Visible = false;
            dataGridView1.Columns["conditionidDataGridViewTextBoxColumn"].Visible = false;
            dataGridView1.Columns["dataGridViewTextBoxColumn1"].Visible = false;
            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].HeaderText = "Назва препарата";
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].HeaderText = "Виробник";
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].HeaderText = "Рік випуску";
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].HeaderText = "Форма";
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].HeaderText = "Строк придатності";
            dataGridView1.Columns["supplier_name"].HeaderText = "Постачальник";
            dataGridView1.Columns["dataGridViewTextBoxColumn2"].HeaderText = "Країна виробник";
            dataGridView1.Columns["condition_type"].HeaderText = "Стан";
            dataGridView1.Columns["priceDataGridViewTextBoxColumn"].HeaderText = "Ціна";
            dataGridView1.Columns["category_name"].HeaderText = "Категорія препарата";
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].HeaderText = "В наявності";

            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].Visible = true;
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].Width = 250;
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].Width = 150;
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].Width = 100;
            dataGridView1.Columns["condition_type"].Width = 200;
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].Width = 100;
            dataGridView1.Columns["category_name"].Width = 200;
            dataGridView1.Columns["dataGridViewTextBoxColumn2"].Width = 100;
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].Width = 120;
            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].Width = 300;

            dataGridView1.Columns["nameDataGridViewTextBoxColumn"].DisplayIndex = 0;
            dataGridView1.Columns["manufacturerDataGridViewTextBoxColumn"].DisplayIndex = 1;
            dataGridView1.Columns["releaseyearDataGridViewTextBoxColumn"].DisplayIndex = 2;
            dataGridView1.Columns["formDataGridViewTextBoxColumn"].DisplayIndex = 3;
            dataGridView1.Columns["expirationdateDataGridViewTextBoxColumn"].DisplayIndex = 4;
            dataGridView1.Columns["category_name"].DisplayIndex = 5;
            dataGridView1.Columns["supplier_name"].DisplayIndex = 6;
            dataGridView1.Columns["condition_type"].DisplayIndex = 7;
            dataGridView1.Columns["priceDataGridViewTextBoxColumn"].DisplayIndex = 8;
            dataGridView1.Columns["dataGridViewTextBoxColumn2"].DisplayIndex = 9;
            dataGridView1.Columns["instockDataGridViewTextBoxColumn"].DisplayIndex = 10;
            dataGridView1.Refresh();

        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            ApplyFilters();
        }

        private void checkBox_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry1 = checkBox.Checked;
            ApplyFilters();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry2 = checkBox1.Checked;
            ApplyFilters();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry3 = checkBox2.Checked;
            ApplyFilters();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie1 = checkBox3.Checked;
            ApplyFilters();
        }

        private void GenerateCoinDescriptionDocument(DataGridViewRow selectedRow)
        {
            Document doc = new Document(PageSize.A4.Rotate());

            BaseFont arial = BaseFont.CreateFont("c:/windows/fonts/arial.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
            iTextSharp.text.Font f_15_bold = new iTextSharp.text.Font(arial, 23, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font f_12_normal = new iTextSharp.text.Font(arial, 17, iTextSharp.text.Font.NORMAL);


            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (*.pdf)|*.pdf";
            saveFileDialog.Title = "Save PDF File";
            saveFileDialog.FileName = "Опис монети" + ".pdf";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                FileStream os = new FileStream(filePath, FileMode.Create);

                using (os)
                {
                    PdfWriter.GetInstance(doc, os);
                    doc.Open();

                    Paragraph line1 = new Paragraph("Документ - \"Опис препарата\"", f_12_normal);
                    line1.Alignment = Element.ALIGN_RIGHT;

                    Paragraph line2 = new Paragraph("виданий додатком PharmacyGo", f_12_normal);
                    line2.Alignment = Element.ALIGN_RIGHT;

                    Paragraph line3 = new Paragraph($"від {DateTime.Now.ToString("dd/MM/yyyy")}", f_12_normal);
                    line3.Alignment = Element.ALIGN_RIGHT;

                    doc.Add(line1);
                    doc.Add(line2);
                    doc.Add(line3);
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));

                    Paragraph title = new Paragraph("Опис препарата - " + selectedRow.Cells[dataGridView1.Columns["nameDataGridViewTextBoxColumn"].Index].Value?.ToString(), f_15_bold);
                    title.Alignment = Element.ALIGN_CENTER;
                    doc.Add(title);

                    Paragraph characteristics = new Paragraph(
                    "Характеристики: " +
                    $"форма -  {selectedRow.Cells["formDataGridViewTextBoxColumn"].Value?.ToString()}, " +
                    $"виробник -  {selectedRow.Cells["manufacturerDataGridViewTextBoxColumn"].Value?.ToString()}, " +
                    $"постачальник -  {selectedRow.Cells["supplier_name"].Value?.ToString()}", f_12_normal);
                    doc.Add(characteristics);


                    Paragraph country = new Paragraph($"Країна виробник: {selectedRow.Cells["dataGridViewTextBoxColumn2"].Value?.ToString()}", f_12_normal);
                    doc.Add(country);

                    Paragraph releaseYear = new Paragraph($"Рік випуску: {selectedRow.Cells["releaseyearDataGridViewTextBoxColumn"].Value?.ToString()}", f_12_normal);
                    doc.Add(releaseYear);

                    Paragraph price = new Paragraph($"Ціна за штуку: {selectedRow.Cells["priceDataGridViewTextBoxColumn"].Value?.ToString()}", f_12_normal);
                    doc.Add(price);
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));
                    doc.Add(new Paragraph(" "));

                    PdfPTable tableHeader = new PdfPTable(2);
                    tableHeader.WidthPercentage = 100;
                    tableHeader.SetWidths(new float[] { 100f, 100f });

                    PdfPCell cellDate = new PdfPCell(new Phrase("Дата: " + DateTime.Now.ToString("dd/MM/yyyy"), f_12_normal));
                    cellDate.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    cellDate.HorizontalAlignment = Element.ALIGN_LEFT;

                    PdfPCell cellShopName = new PdfPCell(new Phrase("PharmacyGo", f_12_normal));
                    cellShopName.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    cellShopName.HorizontalAlignment = Element.ALIGN_RIGHT;

                    tableHeader.AddCell(cellDate);
                    tableHeader.AddCell(cellShopName);

                    doc.Add(tableHeader);

                    doc.Close();
                    System.Diagnostics.Process.Start(filePath);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                GenerateCoinDescriptionDocument(selectedRow);
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry4 = checkBox15.Checked;
            ApplyFilters();
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry5 = checkBox16.Checked;
            ApplyFilters();
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            filterByCountry6 = checkBox17.Checked;
            ApplyFilters();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie2 = checkBox4.Checked;
            ApplyFilters();
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie3 = checkBox18.Checked;
            ApplyFilters();
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie4 = checkBox19.Checked;
            ApplyFilters();
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            filterByCategorie5 = checkBox20.Checked;
            ApplyFilters();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            filterByForm1 = checkBox7.Checked;
            ApplyFilters();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            filterByForm2 = checkBox6.Checked;
            ApplyFilters();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            filterByForm3 = checkBox5.Checked;
            ApplyFilters();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            var review = new Review();
            if (review.ShowDialog() == DialogResult.OK)
            {
                this.feedbackTableAdapter.Fill(this.pharmacyDataSet.feedback);
                pharmacyDataSet.AcceptChanges();
            }
            button9.Visible = true;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            var stat = new Reviews();
            stat.ShowDialog();
        }
    }
}
