﻿using CourseWork.PharmacyDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Reviews : Form
    {
        public Reviews()
        {
            InitializeComponent();
            dataGridView3.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView3.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView3.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView3.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
        }

        private void Reviews_Load(object sender, EventArgs e)
        {

            var adapter = new PharmacyDataSetTableAdapters.feedbackTableAdapter();
            var table = adapter.GetDataByReviewDisplay();
            dataGridView3.DataSource = table;

            dataGridView3.Columns["medicine_id"].Visible = false;
            dataGridView3.Columns["feedback_id"].Visible = false;
            dataGridView3.Columns["client_id"].Visible = false;
            dataGridView3.Columns["feedback_date"].Visible = false;
            dataGridView3.Columns["comment"].Visible = false;
            dataGridView3.Columns["rating"].Visible = false;

            dataGridView3.Columns["ПІБ клієнта"].Width = 250;
            dataGridView3.Columns["Тема відгуку"].Width = 250;
            dataGridView3.Columns["Оцінка"].Width = 70;
            dataGridView3.Columns["Коментар"].Width = 400;
            dataGridView3.Columns["Дата відгуку"].Width = 200;
        }
    }
}
