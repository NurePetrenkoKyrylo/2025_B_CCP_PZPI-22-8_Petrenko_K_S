﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class CondForm : Form
    {
        private readonly int id;
        readonly bool edit;

        public CondForm()
        {
            InitializeComponent();
            edit = false;
        }

        public CondForm(int id, string name, int discount)
        : this()
        {
            edit = true;
            this.id = id;
            textBox_name.Text = name;
            textBox_discount.Text = discount.ToString();
        }

        private void CondForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "coinsDataSet.conditions". При необходимости она может быть перемещена или удалена.
            this.conditionsTableAdapter.Fill(this.pharmacyDataSet.conditions);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (edit)
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_discount.Text))

                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!int.TryParse(textBox_discount.Text, out int diameter))
                {
                    MessageBox.Show("Будь ласка введіть коректні цифрові значення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidString(textBox_name.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                conditionsTableAdapter.UpdateQuery(
                textBox_name.Text,
                Convert.ToInt32(textBox_discount.Text), id);
            }
            else
            {
                conditionsTableAdapter.InsertQuery(
                textBox_name.Text,
                Convert.ToInt32(textBox_discount.Text));
            }
            Close();
        }

        private bool IsValidString(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }
    }
}
