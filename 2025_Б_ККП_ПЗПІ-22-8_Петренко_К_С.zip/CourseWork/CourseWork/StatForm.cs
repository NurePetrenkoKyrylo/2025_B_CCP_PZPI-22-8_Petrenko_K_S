﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class StatForm : Form
    {
        public StatForm()
        {
            InitializeComponent();
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.ReadOnly = true;
            dataGridView2.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView2.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView2.DefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView2.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView2.ReadOnly = true;
            dataGridView3.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView3.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView3.DefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView3.ColumnHeadersDefaultCellStyle.Font = new Font("Arial", 14, FontStyle.Regular);
            dataGridView3.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView3.ReadOnly = true;
        }

        private void StatForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.medicine". При необходимости она может быть перемещена или удалена.
            this.medicineTableAdapter.Fill(this.pharmacyDataSet.medicine);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.orders". При необходимости она может быть перемещена или удалена.
            this.ordersTableAdapter.Fill(this.pharmacyDataSet.orders);
            this.ordersTableAdapter.FillByStat(this.pharmacyDataSet.orders);
            this.ordersTableAdapter.FillByMonth(this.pharmacyDataSet.orders);
            this.medicineTableAdapter.FillByStatMedicine(this.pharmacyDataSet.medicine);
            dataGridView1.AutoGenerateColumns = true;
            dataGridView2.AutoGenerateColumns = true;
            dataGridView3.AutoGenerateColumns = true;
            dataGridView1.Columns["Кількість проданих ліків"].Width = 257;
            dataGridView1.Visible = true;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            dataGridView2.Visible = false;
            dataGridView3.Visible = false;
            this.medicineTableAdapter.FillByStatMedicine(this.pharmacyDataSet.medicine);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = true;
            dataGridView3.Visible = false;
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = ordersBindingSource;
            this.ordersTableAdapter.FillByStat(this.pharmacyDataSet.orders);
            dataGridView2.Columns["order_id"].Visible = false;
            dataGridView2.Columns["client_id"].Visible = false;
            dataGridView2.Columns["cart_date"].Visible = false;
            dataGridView2.Columns["total_amount"].Visible = false;
            dataGridView2.Columns["month_number"].Visible = false;
            dataGridView2.Columns["Місяці"].Visible = false;
            dataGridView2.Columns["Прибуток за місяць"].Visible = false;
            dataGridView2.Columns["ПІБ клієнта"].Width = 435;
            dataGridView2.Columns["Загальна сума покупок"].Width = 270;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView2.Visible = false;
            dataGridView3.Visible = true;
            dataGridView3.DataSource = null;
            dataGridView3.DataSource = ordersBindingSource;
            this.ordersTableAdapter.FillByMonth(this.pharmacyDataSet.orders);
            dataGridView3.Columns["order_id"].Visible = false;
            dataGridView3.Columns["client_id"].Visible = false;
            dataGridView3.Columns["order_id"].Visible = false;
            dataGridView3.Columns["cart_date"].Visible = false;
            dataGridView3.Columns["total_amount"].Visible = false;
            dataGridView3.Columns["ПІБ клієнта"].Visible = false;
            dataGridView3.Columns["Загальна сума покупок"].Visible = false;
            dataGridView3.Columns["month_number"].Visible = false;
            dataGridView3.Columns["Місяці"].Width = 428;
            dataGridView3.Columns["Прибуток за місяць"].Width = 260;
        }
    }
}
