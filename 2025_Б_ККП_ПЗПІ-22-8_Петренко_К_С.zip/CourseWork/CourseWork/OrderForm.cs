﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class OrderForm : Form
    {
        private int client_id;
        public OrderForm(int client_id)
        {
            InitializeComponent();
            this.client_id = client_id;

            dataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            dataGridView1.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Arial", 14, FontStyle.Regular);
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.ReadOnly = false;
        }

        private void OrderForm_Load(object sender, EventArgs e)
        {
            // Загрузка заказов только для выбранного клиента
            ordersTableAdapter.FillBy(pharmacyDataSet.orders, client_id);

            dataGridView1.Columns["orderidDataGridViewTextBoxColumn"].HeaderText = "Номер заказу";
            dataGridView1.Columns["cartdateDataGridViewTextBoxColumn"].HeaderText = "Дата заказу";
            dataGridView1.Columns["totalamountDataGridViewTextBoxColumn"].HeaderText = "Сума заказу";

            dataGridView1.Columns["orderidDataGridViewTextBoxColumn"].Width = 157;
            dataGridView1.Columns["cartdateDataGridViewTextBoxColumn"].Width = 250;
            dataGridView1.Columns["totalamountDataGridViewTextBoxColumn"].Width = 260;
        }
    }
}
