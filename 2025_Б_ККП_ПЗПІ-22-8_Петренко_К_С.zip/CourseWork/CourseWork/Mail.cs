﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace CourseWork
{
    internal class Mail
    {
        private DataSet coinsDataSet = new DataSet();
        private int client_id;

        private List<string> GetClientEmails()
        {
            List<string> clientEmails = new List<string>();

            DataRow[] notificationRows = coinsDataSet.Tables["NotificationRequests"].Select($"emailSent = 0");

            foreach (DataRow notificationRow in notificationRows)
            {
                int client_idFromNotification = Convert.ToInt32(notificationRow["client_id"]);

                DataRow[] clientRows = coinsDataSet.Tables["client"].Select($"client_id = {client_idFromNotification}");

                if (clientRows.Length > 0)
                {
                    notificationRow["emailSent"] = 1;

                    clientEmails.Add(clientRows[0]["email"].ToString());
                }
            }

            return clientEmails;
        }

        public static MailMessage CreateMail(string clientEmail)
        {
            var from = new MailAddress("pharmacygo504@gmail.com", "Додаток");
            var to = new MailAddress(clientEmail);
            var mail = new MailMessage(from, to);
            mail.Subject = "Додаток PharmacyGo";
            mail.Body = "Ваш препарат з'явився в наявності";
            mail.IsBodyHtml = true;
            return mail;
        }

        public static void SendMail(MailMessage mail, string smtpServer, int smtpPort, string emailFrom, string pass)
        {
            using (SmtpClient smtp = new SmtpClient(smtpServer, smtpPort))
            {
                smtp.Credentials = new NetworkCredential(emailFrom, pass);
                smtp.EnableSsl = true;
                smtp.Send(mail);
            }
        }
    }
}
