﻿using CourseWork.PharmacyDataSetTableAdapters;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.Text.RegularExpressions;

namespace CourseWork
{
    public partial class MedicineForm : Form
    {
        private readonly int id;
        readonly bool edit;
        private int client_id;
        private int condition_type;
        private int category_name;
        private int supplier_name;

        public MedicineForm()
        {
            InitializeComponent();
            categoriesTableAdapter.Fill(pharmacyDataSet.categories);
            conditionsTableAdapter.Fill(pharmacyDataSet.conditions);
            suppliersTableAdapter.Fill(pharmacyDataSet.suppliers);
            edit = false;
        }

        private int? selectedCategoryId = null;
        private int? selectedSupplierId = null;
        private int? selectedConditionId = null;


        public MedicineForm(int id, string name, string manufacturer, int releaseYear, string form,
            DateTime expirationDate, int categoryId, int supplierId, int conditionId,
            int price, string countryOfOrigin, int inStock)
            : this()
        {
            edit = true;
            this.id = id;

            textBox_name.Text = name;
            textBox_manufacturer.Text = manufacturer;
            textBox_relyear.Text = releaseYear.ToString();
            textBox_form.Text = form;
            textBox_expdate.Text = expirationDate.ToShortDateString();
            textBox_price.Text = price.ToString();
            textBox_country.Text = countryOfOrigin;
            textBox_stock.Text = inStock.ToString();

            // Сохраняем для установки позже
            selectedCategoryId = categoryId;
            selectedSupplierId = supplierId;
            selectedConditionId = conditionId;
        }




        private void MedicineForm_Load(object sender, EventArgs e)
        {
            this.categoriesTableAdapter.Fill(this.pharmacyDataSet.categories);
            this.conditionsTableAdapter.Fill(this.pharmacyDataSet.conditions);
            this.suppliersTableAdapter.Fill(this.pharmacyDataSet.suppliers);
            this.medicineTableAdapter.Fill(this.pharmacyDataSet.medicine);

            // Теперь можно установить значения
            if (selectedCategoryId.HasValue)
                comboBox1.SelectedValue = selectedCategoryId.Value;

            if (selectedSupplierId.HasValue)
                comboBox_supplier.SelectedValue = selectedSupplierId.Value;

            if (selectedConditionId.HasValue)
                comboBox_condition.SelectedValue = selectedConditionId.Value;
        }


        private List<string> GetClientEmail()
        {
            List<string> clientEmails = new List<string>();

            clientTableAdapter.Fill(pharmacyDataSet.client);
            notificationRequestsTableAdapter.Fill(pharmacyDataSet.NotificationRequests);

            DataRow[] notificationRows = pharmacyDataSet.Tables["NotificationRequests"].Select($"emailSent = 0");

            if (notificationRows.Length == 0)
            {
                return clientEmails;
            }

            foreach (DataRow notificationRow in notificationRows)
            {
                int client_idFromNotification = Convert.ToInt32(notificationRow["client_id"]);

                DataRow[] clientRows = pharmacyDataSet.Tables["client"].Select($"client_id = {client_idFromNotification}");

                if (clientRows.Length > 0)
                {
                    notificationRow["emailSent"] = 1;

                    notificationRequestsTableAdapter.Update(pharmacyDataSet.NotificationRequests);

                    clientEmails.Add(clientRows[0]["email"].ToString());
                }
            }

            return clientEmails;
        }


        private void CheckAndSendNotification()
        {
            List<string> clientEmails = GetClientEmail();

            if (notificationRequested && clientEmails.Count > 0)
            {
                foreach (var email in clientEmails)
                {
                    var mail = Mail.CreateMail(email);

                    try
                    {
                        Mail.SendMail(mail, "smtp.gmail.com", 587, "pharmacygo504@gmail.com", "jabudgkjmusqamcm");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка при відправленні повідомлення: {ex.Message}", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                notificationRequested = false; // Помечаем уведомление как отправленное после отправки всем адресатам
            }
        }


        private bool notificationRequested = false;

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                string.IsNullOrWhiteSpace(textBox_manufacturer.Text) ||
                string.IsNullOrWhiteSpace(textBox_relyear.Text) ||
                string.IsNullOrWhiteSpace(textBox_form.Text) ||
                string.IsNullOrWhiteSpace(textBox_expdate.Text) ||
                comboBox1.SelectedValue == null ||
                comboBox_supplier.SelectedValue == null ||
                comboBox_condition.SelectedValue == null ||
                string.IsNullOrWhiteSpace(textBox_price.Text) ||
                string.IsNullOrWhiteSpace(textBox_country.Text) ||
                string.IsNullOrWhiteSpace(textBox_stock.Text))
            {
                MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(textBox_relyear.Text, out int releaseYear) ||
                !DateTime.TryParse(textBox_expdate.Text, out DateTime expirationDate) ||
                !int.TryParse(textBox_price.Text, out int price) ||
                !int.TryParse(textBox_stock.Text, out int inStock))
            {
                MessageBox.Show("Будь ласка введіть коректні цифрові значення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!IsValidString(textBox_name.Text) ||
                !IsValidString(textBox_manufacturer.Text) ||
                !IsValidString(textBox_form.Text) ||
                !IsValidString(textBox_country.Text))
            {
                MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (edit)
            {
                // Получаем оригинальный остаток до обновления
                int original_in_stock = Convert.ToInt32(pharmacyDataSet.medicine.FindBymedicine_id(id)?.in_stock ?? 0);

                // Обновляем запись
                medicineTableAdapter.UpdateQuery(
                    textBox_name.Text,
                    textBox_manufacturer.Text,
                    Convert.ToInt32(textBox_relyear.Text),
                    textBox_form.Text,
                    expirationDate.ToShortDateString(),
                    Convert.ToInt32(comboBox1.SelectedValue),
                    Convert.ToInt32(comboBox_supplier.SelectedValue),
                    Convert.ToInt32(comboBox_condition.SelectedValue),
                    Convert.ToInt32(textBox_price.Text),
                    textBox_country.Text,
                    Convert.ToInt32(textBox_stock.Text),
                    id);

                // Обновляем локальный DataSet (до поиска!)
                medicineTableAdapter.FillBy2(pharmacyDataSet.medicine);

                int new_in_stock = Convert.ToInt32(pharmacyDataSet.medicine.FindBymedicine_id(id).in_stock);
                /*                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];*/
                if (new_in_stock > 0 && original_in_stock == 0)
                {
                    notificationRequested = true;
                    // int coinId = Convert.ToInt32(selectedRow.Cells["coin_id"].Value);

                    CheckAndSendNotification();
                }

            }
            else
            {
                medicineTableAdapter.InsertQuery(
                    textBox_name.Text,
                    textBox_manufacturer.Text,
                    Convert.ToInt32(textBox_relyear.Text),
                    textBox_form.Text,
                    expirationDate.ToShortDateString(),
                    Convert.ToInt32(comboBox1.SelectedValue),
                    Convert.ToInt32(comboBox_supplier.SelectedValue),
                    Convert.ToInt32(comboBox_condition.SelectedValue),
                    Convert.ToInt32(textBox_price.Text),
                    textBox_country.Text,
                    Convert.ToInt32(textBox_stock.Text));
            }

            Close();
        }

        private bool IsValidString(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }


    }
}
