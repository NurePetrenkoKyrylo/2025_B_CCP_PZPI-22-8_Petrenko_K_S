﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class ClientsForm : Form
    {
        private readonly int id;
        readonly bool edit;

        public ClientsForm()
        {
            InitializeComponent();
            edit = false;
        }

        public ClientsForm(int id, string cleint_first_name, string client_last_name, string client_father_name,
                           string country, string phone, string email, string address)
        : this()
        {
            edit = true;
            this.id = id;
            textBox_name.Text = cleint_first_name;
            textBox_lastname.Text = client_last_name;
            textBox_fathername.Text = client_father_name;
            textBox_country.Text = country;
            textBox_phone.Text = phone;
            textBox_email.Text = email;
            textBox_address.Text = address;
        }

        private void ClientsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "coinsDataSet.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.pharmacyDataSet.client);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (edit)
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_lastname.Text) ||
                    string.IsNullOrWhiteSpace(textBox_fathername.Text) ||
                    string.IsNullOrWhiteSpace(textBox_country.Text) ||
                    string.IsNullOrWhiteSpace(textBox_phone.Text) ||
                    string.IsNullOrWhiteSpace(textBox_email.Text) ||
                    string.IsNullOrWhiteSpace(textBox_address.Text))
                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate phone number
                if (!IsValidPhoneNumber(textBox_phone.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний номер телефону.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate email
                if (!IsValidEmail(textBox_email.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний email.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate text fields
                if (!IsValidString(textBox_name.Text) ||
                    !IsValidString(textBox_lastname.Text) ||
                    !IsValidString(textBox_fathername.Text) ||
                    !IsValidString(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                clientTableAdapter.UpdateQuery(
                textBox_name.Text,
                textBox_lastname.Text,
                textBox_fathername.Text,
                textBox_country.Text,
                textBox_phone.Text,
                textBox_email.Text,
                textBox_address.Text, id);
            }
            else
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_lastname.Text) ||
                    string.IsNullOrWhiteSpace(textBox_fathername.Text) ||
                    string.IsNullOrWhiteSpace(textBox_country.Text) ||
                    string.IsNullOrWhiteSpace(textBox_phone.Text) ||
                    string.IsNullOrWhiteSpace(textBox_email.Text) ||
                    string.IsNullOrWhiteSpace(textBox_address.Text))
                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate phone number
                if (!IsValidPhoneNumber(textBox_phone.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний номер телефону.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate email
                if (!IsValidEmail(textBox_email.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний email.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate text fields
                if (!IsValidString(textBox_name.Text) ||
                    !IsValidString(textBox_lastname.Text) ||
                    !IsValidString(textBox_fathername.Text) ||
                    !IsValidString(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                clientTableAdapter.InsertQuery(
                textBox_name.Text,
                textBox_lastname.Text,
                textBox_fathername.Text,
                textBox_country.Text,
                textBox_phone.Text,
                textBox_email.Text,
                textBox_address.Text);
            }
            Close();
        }

        private bool IsValidString(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return Regex.IsMatch(phoneNumber, @"^\+?\d{0,14}[\d\s-]*$");
        }
    }
}
