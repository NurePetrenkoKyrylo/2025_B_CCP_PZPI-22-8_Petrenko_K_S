﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class CategoriesForm : Form
    {
        private readonly int id;
        readonly bool edit;

        public CategoriesForm()
        {
            InitializeComponent();
            edit = false;
        }

        public CategoriesForm(int id, string name, int num_of_medicines)
       : this()
        {
            edit = true;
            this.id = id;
            textBox_name.Text = name;
            textBox_num.Text = num_of_medicines.ToString();
        }

        private void CollectForm_Load(object sender, EventArgs e)
        {
            this.categoriesTableAdapter.Fill(this.pharmacyDataSet.categories);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (edit)
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_num.Text))

                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!int.TryParse(textBox_num.Text, out int diameter))
                {
                    MessageBox.Show("Будь ласка введіть коректні цифрові значення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidString(textBox_name.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                categoriesTableAdapter.UpdateQuery(
                textBox_name.Text,
                Convert.ToInt32(textBox_num.Text), id);
            }
            else
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_num.Text))

                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!int.TryParse(textBox_num.Text, out int diameter))
                {
                    MessageBox.Show("Будь ласка введіть коректні цифрові значення.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidString(textBox_name.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                categoriesTableAdapter.InsertQuery(
                textBox_name.Text,
                Convert.ToInt32(textBox_num.Text));
            }
            Close();
        }

        private bool IsValidString(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }
    }
}
