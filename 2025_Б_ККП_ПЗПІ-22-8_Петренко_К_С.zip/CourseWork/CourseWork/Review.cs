﻿using CourseWork.PharmacyDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class Review : Form
    {
        private readonly int feedback_id;
        readonly bool edit;

        public Review()
        {
            InitializeComponent();
            edit = false;
        }

        public Review(int feedback_id, int client_id, int medicine_id, int rating,
                           string comment, DateTime feedback_date)
        : this()
        {
            edit = true;
            this.feedback_id = feedback_id;
            comboBox_client.SelectedValue = client_id;
            comboBox_medicine.SelectedValue = medicine_id;
            comboBox_rating.SelectedItem = rating;
            textBox2.Text = comment;
        }

        private void Review_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.client". При необходимости она может быть перемещена или удалена.
            this.clientTableAdapter.Fill(this.pharmacyDataSet.client);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pharmacyDataSet.medicine". При необходимости она может быть перемещена или удалена.
            this.medicineTableAdapter.Fill(this.pharmacyDataSet.medicine);
            comboBox_client.DataSource = pharmacyDataSet.client;
            comboBox_client.DisplayMember = "client_first_name";
            comboBox_client.ValueMember = "client_id";

            // Загрузка лекарств
            medicineTableAdapter.Fill(pharmacyDataSet.medicine);
            DataTable medicineTable = pharmacyDataSet.medicine.Copy();

            // Добавляем "Відгук не про ліки"
            DataRow noMedicineRow = medicineTable.NewRow();
            noMedicineRow["medicine_id"] = 0;
            noMedicineRow["name"] = "Відгук не про ліки";
            medicineTable.Rows.InsertAt(noMedicineRow, 0);

            comboBox_medicine.DataSource = medicineTable;
            comboBox_medicine.DisplayMember = "medicine_name";
            comboBox_medicine.ValueMember = "medicine_id";

            // Рейтинг 1–5
            comboBox_rating.Items.AddRange(new object[] { 1, 2, 3, 4, 5 });
            comboBox_rating.SelectedIndex = 4; // По умолчанию 5


        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime feedbackDate = DateTime.Now;

            // Проверка полей
            if (comboBox_client.SelectedValue == null ||
                comboBox_rating.SelectedItem == null ||
                string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Будь ласка, заповніть усі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Проверка комментария
            if (!IsValidComment(textBox2.Text))
            {
                MessageBox.Show("Коментар повинен містити лише літери, цифри, пробіли та розділові знаки.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }



            var feedbackTableAdapter = new feedbackTableAdapter();

            if (edit)
            {
                int clientId = Convert.ToInt32(((DataRowView)comboBox_client.SelectedItem)["client_id"]);
                object selectedMedicine = comboBox_medicine.SelectedValue;
                int? medicineId = (selectedMedicine != null && Convert.ToInt32(selectedMedicine) != 0)
                    ? Convert.ToInt32(selectedMedicine)
                    : (int?)null;

                feedbackTableAdapter.UpdateQuery(
    clientId,
    medicineId,
    Convert.ToInt32(comboBox_rating.SelectedItem),
    textBox2.Text,
    feedbackDate.ToShortDateString(),
    feedback_id);
            }
            else
            {
                int clientId = Convert.ToInt32(((DataRowView)comboBox_client.SelectedItem)["client_id"]);
                object selectedMedicine = comboBox_medicine.SelectedValue;
                int? medicineId = (selectedMedicine != null && Convert.ToInt32(selectedMedicine) != 0)
                    ? Convert.ToInt32(selectedMedicine)
                    : (int?)null;

                feedbackTableAdapter.InsertQuery(
                    clientId,
                    medicineId,
                    Convert.ToInt32(comboBox_rating.SelectedItem),
                    textBox2.Text,
                    feedbackDate.ToShortDateString());

            }

            Close();
        }

        private bool IsValidComment(string input)
        {
            return Regex.IsMatch(input, @"^[\w\s.,!?-]{1,500}$"); // максимум 500 символів, можна адаптувати
        }

    }
}
