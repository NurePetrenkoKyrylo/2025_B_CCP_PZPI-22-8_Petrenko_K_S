﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class SuppliersForm : Form
    {

        private readonly int id;
        readonly bool edit;

        public SuppliersForm()
        {
            InitializeComponent();
            edit = false;
        }

        public SuppliersForm(int id, string name, string email, string phone, string country)
        : this()
        {
            edit = true;
            this.id = id;
            textBox_name.Text = name;
            textBox_email.Text = email;
            textBox_phone.Text = phone;
            textBox_country.Text = country;
        }

        private void Suppliers_Load(object sender, EventArgs e)
        {
            this.suppliersTableAdapter.FillBy(this.pharmacyDataSet.suppliers);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (edit)
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_email.Text) ||
                    string.IsNullOrWhiteSpace(textBox_phone.Text) ||
                    string.IsNullOrWhiteSpace(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidPhoneNumber(textBox_phone.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний номер телефону.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidEmail(textBox_email.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний email.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!IsValidString(textBox_name.Text) ||
                    !IsValidString(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                suppliersTableAdapter.UpdateQuery(
                textBox_name.Text,
                textBox_email.Text,
                textBox_phone.Text,
                textBox_country.Text, id);
            }
            else
            {

                if (string.IsNullOrWhiteSpace(textBox_name.Text) ||
                    string.IsNullOrWhiteSpace(textBox_email.Text) ||
                    string.IsNullOrWhiteSpace(textBox_phone.Text) ||
                    string.IsNullOrWhiteSpace(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка заповніть всі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate phone number
                if (!IsValidPhoneNumber(textBox_phone.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний номер телефону.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate email
                if (!IsValidEmail(textBox_email.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний email.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Validate text fields
                if (!IsValidString(textBox_name.Text) ||
                    !IsValidString(textBox_country.Text))
                {
                    MessageBox.Show("Будь ласка введіть коректний текст.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }


                suppliersTableAdapter.InsertQuery(
                textBox_name.Text,
                textBox_email.Text,
                textBox_phone.Text,
                textBox_country.Text);

            }
            Close();
        }
        private bool IsValidString(string input)
        {
            return !string.IsNullOrWhiteSpace(input) && input.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return Regex.IsMatch(phoneNumber, @"^\+?\d{0,14}[\d\s-]*$");
        }
    }
}
